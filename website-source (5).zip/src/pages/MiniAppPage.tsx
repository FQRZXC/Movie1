import MiniApp from '@/components/miniapp/MiniApp'

export default function MiniAppPage() {
  return <MiniApp />
}
