import { useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import CampaignBuilderModal from '@/components/CampaignBuilderModal'
import { useAuth } from '@/lib/auth-context'

const fade = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-60px' } as const,
  transition: { delay, duration: 0.5 },
})

const stats = [
  { value: '50M+', label: 'Telegram users' },
  { value: '< 0.5$', label: 'CPM from' },
  { value: '24h', label: 'Campaign launch' },
  { value: '98%', label: 'Delivery' },
]

const features = [
  { icon: '🎯', title: 'Precise targeting', desc: 'By geo, interests, languages, and Telegram behavior' },
  { icon: '📊', title: 'Transparent analytics', desc: 'Reach, clicks, and conversions in real time' },
  { icon: '⚡', title: 'Fast launch', desc: 'Campaign starts within 24 hours after payment' },
  { icon: '💰', title: 'Flexible budget', desc: 'From $1,000 with no hidden fees or subscriptions' },
  { icon: '🤖', title: 'Automation', desc: 'Automatic optimization of bids and impressions' },
  { icon: '🔒', title: 'Security', desc: 'Data protection and encryption for all transactions' },
]

const formats = [
  { icon: '📰', name: 'Native', desc: 'Ads in the Telegram feed' },
  { icon: '🖼', name: 'Banners', desc: 'Visual blocks in header and footer' },
  { icon: '🔔', name: 'Push', desc: 'Direct user notifications' },
  { icon: '📱', name: 'Stories', desc: 'Vertical format for mobile' },
]

const pricing = [
  { name: 'Starter', price: '1 000', features: ['Native ads', 'Basic targeting', 'Real-time analytics', 'Email support'], accent: false },
  { name: 'Business', price: '5 000', features: ['All formats', 'Extended targeting', 'Campaign automation', 'Priority support', 'A/B testing'], accent: true },
  { name: 'Enterprise', price: '25 000+', features: ['All formats + Stories', 'Personal manager', 'API integration', 'SLA 99.9%', 'Custom solutions'], accent: false },
]

const faq = [
  { q: 'How fast does a campaign launch?', a: 'A campaign starts within 24 hours after payment confirmation and creative review.' },
  { q: 'What payment methods are accepted?', a: 'We accept USDT (TRC-20, ERC-20, BEP-20). Minimum top-up is $1,000.' },
  { q: 'How does targeting work?', a: 'You choose geography, language, interests, and demographics. The system automatically optimizes impressions for maximum conversion.' },
  { q: 'Can I change a campaign after launch?', a: 'Yes, you can pause, change the budget or targeting at any time from the dashboard.' },
  { q: 'Is there a minimum budget?', a: 'Yes, the minimum top-up is $1,000. This allows you to test the platform without large investments.' },
]

export default function Home() {
  const [campaignOpen, setCampaignOpen] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const { user, isInTelegram } = useAuth()

  return (
    <div className="min-h-screen bg-[#070b14] text-white">
      <Header onCampaignOpen={() => setCampaignOpen(true)} />

      {/* Hero */}
      <section id="hero" className="relative pt-32 pb-20 lg:pt-40 lg:pb-28">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/2 h-[600px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#6d5aef]/10 blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div {...fade()} className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-sm text-gray-300 mb-8">
            <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
            Production platform
          </motion.div>
          <motion.h1 {...fade(0.1)} className="text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight mb-6">
            Telegram advertising<br />
            <span className="gradient-text">with precise targeting</span>
          </motion.h1>
          <motion.p {...fade(0.15)} className="text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-10">
            Launch Telegram campaigns in a few clicks. Transparent analytics, flexible budget, and cryptocurrency payments.
          </motion.p>
          <motion.div {...fade(0.2)} className="flex flex-col sm:flex-row items-center justify-center gap-4">
            {user && isInTelegram ? (
              <button onClick={() => setCampaignOpen(true)} className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#6d5aef] to-[#7c3aed] text-white font-medium hover:opacity-90 transition-opacity">
                Open dashboard
              </button>
            ) : (
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-2">Open the app through the Telegram bot</p>
                <a href="https://t.me/Imeadsrubot" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#6d5aef] to-[#7c3aed] text-white font-medium hover:opacity-90 transition-opacity">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                  </svg>
                  Open in Telegram
                </a>
              </div>
            )}
            <a href="#platform" className="px-8 py-3.5 rounded-xl border border-white/10 text-gray-300 hover:bg-white/5 transition-colors">
              Learn more
            </a>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <motion.div key={s.label} {...fade(i * 0.05)} className="text-center">
              <div className="text-3xl font-bold gradient-text">{s.value}</div>
              <div className="text-sm text-gray-500 mt-1">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="platform" className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div {...fade()} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Why imeads</h2>
            <p className="text-gray-400 max-w-xl mx-auto">Everything you need for effective Telegram advertising in one place</p>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div key={f.title} {...fade(i * 0.05)} className="glass rounded-2xl p-6 hover:border-white/10 transition-colors">
                <div className="text-3xl mb-4">{f.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Formats */}
      <section id="formats" className="py-20 lg:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div {...fade()} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ad Formats</h2>
            <p className="text-gray-400 max-w-xl mx-auto">Choose the optimal format for your goals</p>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {formats.map((f, i) => (
              <motion.div key={f.name} {...fade(i * 0.05)} className="glass rounded-2xl p-6 text-center">
                <div className="text-4xl mb-4">{f.icon}</div>
                <h3 className="font-semibold mb-2">{f.name}</h3>
                <p className="text-sm text-gray-400">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 lg:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div {...fade()} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Pricing</h2>
            <p className="text-gray-400 max-w-xl mx-auto">Choose the plan that fits you best</p>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {pricing.map((p, i) => (
              <motion.div key={p.name} {...fade(i * 0.05)}
                className={`rounded-2xl p-8 ${p.accent ? 'bg-gradient-to-b from-[#6d5aef]/20 to-transparent border-2 border-[#6d5aef]/40' : 'glass'}`}>
                <h3 className="text-lg font-semibold mb-2">{p.name}</h3>
                <div className="text-4xl font-bold mb-1">${p.price}</div>
                <div className="text-sm text-gray-500 mb-6">top-up</div>
                <ul className="space-y-3 mb-8">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-gray-300">
                      <svg className="w-4 h-4 text-[#6d5aef] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => setCampaignOpen(true)}
                  className={`w-full py-3 rounded-xl font-medium transition-opacity ${p.accent ? 'bg-[#6d5aef] text-white hover:opacity-90' : 'border border-white/10 text-gray-300 hover:bg-white/5'}`}>
                  Start
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 lg:py-28 border-t border-white/5">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div {...fade()} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          </motion.div>
          <div className="space-y-3">
            {faq.map((item, i) => (
              <motion.div key={i} {...fade(i * 0.03)} className="glass rounded-xl overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between px-6 py-4 text-left">
                  <span className="font-medium text-sm">{item.q}</span>
                  <svg className={`w-5 h-5 text-gray-500 shrink-0 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-4 text-sm text-gray-400 leading-relaxed">{item.a}</div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 lg:py-28 border-t border-white/5">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div {...fade()}>
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ready to launch ads?</h2>
            <p className="text-gray-400 mb-8">Start promoting right now — minimum top-up from $1,000</p>
            {user && isInTelegram ? (
              <button onClick={() => setCampaignOpen(true)} className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#6d5aef] to-[#7c3aed] text-white font-medium hover:opacity-90 transition-opacity">
                Create campaign
              </button>
            ) : (
              <a href="https://t.me/Imeadsrubot" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#6d5aef] to-[#7c3aed] text-white font-medium hover:opacity-90 transition-opacity">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                </svg>
                Open in Telegram
              </a>
            )}
          </motion.div>
        </div>
      </section>

      <Footer />
      <CampaignBuilderModal open={campaignOpen} onClose={() => setCampaignOpen(false)} />
    </div>
  )
}
