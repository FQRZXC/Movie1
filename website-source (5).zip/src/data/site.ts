export const brand = {
  name: 'imeads',
  tagline: 'Advertising platform for Telegram',
  description:
    'Telegram advertising infrastructure: fast launch, transparent analytics, one-click subscriptions, and audience growth based on real user behavior.',
  url: '/',
}

export const navigation = [
  { id: 'product', label: 'Product', href: '#product' },
  { id: 'how', label: 'How It Works', href: '#how-it-works' },
  { id: 'audience', label: 'Audience', href: '#audience' },
  { id: 'pricing', label: 'Pricing', href: '#pricing' },
  { id: 'faq', label: 'FAQ', href: '#faq' },
]

export const metrics = [
  { label: 'Installs', value: '20 000 000+', description: 'total Telegram user base' },
  { label: 'Monthly Audience', value: '10 000 000+', description: 'active users' },
  { label: 'Daily Audience', value: '1 000 000+', description: 'engaged users' },
  { label: 'Regions', value: '15+', description: 'active markets' },
  { label: 'On Market', value: '8+', description: 'years of platform history' },
]

export const problemComparison = {
  title: 'Same click. Different result.',
  subtitle: 'Traditional ads lose users before they subscribe. Our approach shortens the path.',
  highlight: {
    value: '65%',
    description: 'of users are lost before the second click',
  },
  traditional: {
    title: 'Traditional advertising',
    steps: ['Click ad', 'Land on page', 'Attempt to subscribe', 'Drop off'],
    conversion: 35,
  },
  platform: {
    title: 'imeads',
    steps: ['Click ad', 'Instant subscribe'],
    conversion: 100,
  },
}

export const featureHighlights = [
  { value: '100%', label: 'post-click conversion' },
  { value: '0%', label: 'extra steps to subscribe' },
  { value: '< 24h', label: 'to first campaign launch' },
]

export const placements = [
  {
    id: 'stories',
    title: 'Stories',
    description: 'Visual cards in the Stories feed for quick reach and memorable impressions.',
    reach: 'Up to 4,000,000 views per day',
    format: 'Full-screen cards with instant interaction',
  },
  {
    id: 'chat-list',
    title: 'Chat List',
    description: 'Sponsored posts directly in the users main chat list.',
    reach: 'Up to 6,200,000 impressions per day',
    format: 'Native posts marked as sponsored',
  },
  {
    id: 'archived',
    title: 'Archived Chats',
    description: 'Extended reach through archived conversations.',
    reach: 'Up to 1,800,000 impressions per day',
    format: 'Compact cards with short messages',
  },
  {
    id: 'channel-feed',
    title: 'Channel Feed',
    description: 'Placement in the subscription feed to reach an already engaged audience.',
    reach: 'Up to 5,500,000 impressions per day',
    format: 'Posts with preview and subscribe button',
  },
  {
    id: 'search',
    title: 'Search',
    description: 'Promoted posts in search results for users with high commercial intent.',
    reach: 'Up to 2,400,000 impressions per day',
    format: 'Cards with headline, description, and target link',
  },
  {
    id: 'bots',
    title: 'Bots & Mini Apps',
    description: 'Integrations inside bots and mini applications.',
    reach: 'Up to 1,600,000 impressions per day',
    format: 'Native blocks inside the user interface',
  },
]

export const advantages = [
  { title: 'One-click subscription', description: 'The user becomes a subscriber immediately with no extra steps.' },
  { title: 'Pay per subscriber', description: 'A transparent model where you see the cost of every result.' },
  { title: 'Crypto audience', description: 'Access to a technically active and paying segment of the audience.' },
  { title: 'Self-service', description: 'You manage campaigns yourself, from targeting to analytics.' },
  { title: 'Low starting budget', description: 'Start with a small amount and scale the results.' },
  { title: 'Fast moderation', description: 'Campaign launch takes minimal time with clear rules.' },
]

export const audienceMetrics = [
  { label: 'Installs', value: '20 000 000+' },
  { label: 'MAU', value: '10 000 000+' },
  { label: 'DAU', value: '1 000 000+' },
  { label: 'Rating', value: '4.7' },
]

export const deviceDistribution = [
  { platform: 'iOS', share: 48 },
  { platform: 'Android', share: 45 },
  { platform: 'Desktop', share: 7 },
]

export const defaultTargeting = {
  country: 'USA',
  language: 'English',
  platform: 'iOS',
  audience: 'Premium + Crypto',
  categories: ['Finance', 'Crypto', 'Technology'],
  estimated: {
    audience: 1_420_000,
    cpm: 2.66,
    reach: 100_000,
  },
}

export const economicsDefaults = {
  budget: 266,
  impressions: 100_000,
  ctr: 1.22,
  clicks: 1220,
  platformConversion: 100,
  traditionalConversion: 35,
  currency: '$',
}

export const comparisonRows = [
  { label: 'Onboarding', platform: 'Launch in minutes', telegram: 'Manual review', other: 'Long integration' },
  { label: 'Post-click conversion', platform: 'Up to 100%', telegram: 'Up to 35%', other: 'Up to 40%' },
  { label: 'Pricing model', platform: 'Pay per subscriber', telegram: 'CPM', other: 'CPM / CPC' },
  { label: 'Minimum budget', platform: 'Low entry barrier', telegram: 'High', other: 'Medium' },
  { label: 'Targeting', platform: 'Platform, language, interests', telegram: 'Basic', other: 'Medium' },
  { label: 'Payment methods', platform: 'Crypto, cards, Stars', telegram: 'Limited', other: 'Limited' },
  { label: 'Placements', platform: '6 key placements', telegram: '1 main', other: '2-3 placements' },
]

export const caseStudy = {
  title: '23,680 subscribers for $4,070',
  stats: [
    { label: 'Impressions', value: '1 850 000' },
    { label: 'CTR', value: '1.28%' },
    { label: 'Subscribers', value: '23 680' },
    { label: 'Cost per subscriber', value: '$0.17' },
  ],
  comparison: {
    platform: 23_680,
    traditional: 8_288,
    delta: 15_392,
  },
}

export const paymentMethods = [
  {
    title: 'Crypto',
    description: 'ETH, USDT, and other tokens for easy top-ups from anywhere in the world.',
    tags: ['ETH', 'USDT', 'Other tokens'],
  },
  {
    title: 'Fiat',
    description: 'Bank cards and local payment methods for a familiar top-up experience.',
    tags: ['Cards', 'Local methods'],
  },
  {
    title: 'In-platform currency',
    description: 'Stars and platform credits for flexible budget management and bonuses.',
    tags: ['Stars', 'Platform credits'],
  },
]

export const howItWorksSteps = [
  { step: '01', title: 'Open the app', description: 'Tap the button in the Telegram bot and log in automatically.' },
  { step: '02', title: 'Top up your balance', description: 'Choose a convenient payment method and add budget.' },
  { step: '03', title: 'Create a campaign', description: 'Set up your audience, placement, and creative in minutes.' },
  { step: '04', title: 'Get subscribers', description: 'Track results in real time and scale the best campaigns.' },
]

export const dashboardMetrics = [
  { label: 'Impressions', value: '148 200' },
  { label: 'Clicks', value: '1 812' },
  { label: 'Subscribers', value: '1 812' },
  { label: 'Spend', value: '$482' },
  { label: 'CPS', value: '$0.27' },
  { label: 'CTR', value: '1.22%' },
]

export const faqItems = [
  {
    question: 'What is imeads?',
    answer:
      'It is an advertising platform for Telegram that helps you find the right audience faster and turn impressions into subscribers.',
  },
  {
    question: 'How does one-click subscription work?',
    answer:
      'A user taps the ad block and immediately becomes a subscriber of the target channel with no extra steps and no drop-off.',
  },
  {
    question: 'How much does advertising cost?',
    answer:
      'The cost depends on the targeting, placement, and format. You always see the forecast before launching a campaign.',
  },
  {
    question: 'Which placements are available?',
    answer:
      'Stories, Chat List, Archived Chats, Channel Feed, Search, as well as Bots & Mini Apps.',
  },
  {
    question: 'Who can I target?',
    answer:
      'Country, language, platform, interests, as well as premium and crypto audiences all through built-in filters.',
  },
  {
    question: 'What payment methods are accepted?',
    answer:
      'Cryptocurrency, bank cards, local methods, and in-platform currency.',
  },
  {
    question: 'How long does moderation take?',
    answer:
      'Standard review takes minimal time. With simple creatives, a campaign can launch on the same day.',
  },
  {
    question: 'Is the audience real?',
    answer:
      'Yes. We work with real Telegram users and do not use bots, clicks farms, or non-targeted installs.',
  },
]

export const footerColumns = [
  {
    title: 'Product',
    links: [
      { label: 'Campaigns', href: '#product' },
      { label: 'Audience', href: '#audience' },
      { label: 'Analytics', href: '#dashboard' },
      { label: 'Pricing', href: '#pricing' },
    ],
  },
  {
    title: 'Resources',
    links: [
      { label: 'Documentation', href: '#faq' },
      { label: 'FAQ', href: '#faq' },
      { label: 'Cases', href: '#cases' },
      { label: 'Support', href: '#cta' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About Us', href: '#advantages' },
      { label: 'Contacts', href: '#cta' },
      { label: 'Terms', href: '#cta' },
      { label: 'Privacy', href: '#cta' },
    ],
  },
]
