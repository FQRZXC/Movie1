import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

interface TelegramUser {
  id: number
  first_name: string
  last_name?: string
  username?: string
  language_code?: string
  is_premium?: boolean
}

interface AuthCtx {
  user: TelegramUser | null
  loading: boolean
  isInTelegram: boolean
  initData: string | null
  signOut: () => void
}

const Ctx = createContext<AuthCtx>({
  user: null,
  loading: true,
  isInTelegram: false,
  initData: null,
  signOut: () => {},
})

function getTelegramWebApp() {
  if (typeof window === 'undefined') return null
  const win = window as unknown as Record<string, unknown>
  const tg = win.Telegram as Record<string, unknown> | undefined
  return tg?.WebApp as Record<string, unknown> | undefined
}

function getTelegramUser(initDataUnsafe: Record<string, unknown> | undefined): TelegramUser | null {
  if (!initDataUnsafe) return null
  const user = initDataUnsafe.user as Record<string, unknown> | undefined
  if (!user) return null
  return {
    id: user.id as number,
    first_name: user.first_name as string,
    last_name: user.last_name as string | undefined,
    username: user.username as string | undefined,
    language_code: user.language_code as string | undefined,
    is_premium: user.is_premium as boolean | undefined,
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<TelegramUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [isInTelegram, setIsInTelegram] = useState(false)
  const [initData, setInitData] = useState<string | null>(null)

  useEffect(() => {
    const tg = getTelegramWebApp()
    if (tg) {
      setIsInTelegram(true)
      const initDataUnsafe = tg.initDataUnsafe as Record<string, unknown> | undefined
      const initDataStr = tg.initData as string | undefined

      if (initDataStr) {
        setInitData(initDataStr)
      }

      const telegramUser = getTelegramUser(initDataUnsafe)
      if (telegramUser) {
        setUser(telegramUser)
      }

      // Ready to display
      if (typeof tg.ready === 'function') {
        tg.ready()
      }
    }
    setLoading(false)
  }, [])

  const signOut = () => {
    setUser(null)
    setInitData(null)
  }

  return (
    <Ctx.Provider value={{ user, loading, isInTelegram, initData, signOut }}>
      {children}
    </Ctx.Provider>
  )
}

export const useAuth = () => useContext(Ctx)

// Helper to check if running in Telegram Mini App
export function isTelegramMiniApp(): boolean {
  const tg = getTelegramWebApp()
  return !!tg
}

// Get Telegram WebApp instance
export function getTelegramMiniApp() {
  return getTelegramWebApp()
}
