export const formatNumber = (value: number, { maximumFractionDigits = 0 }: { maximumFractionDigits?: number } = {}) =>
  new Intl.NumberFormat('ru-RU', { maximumFractionDigits }).format(value)

export const formatCurrency = (value: number) => `$${formatNumber(value, { maximumFractionDigits: 2 })}`
