export const config = {
  brand: 'imeads',
  tagline: 'Advertising platform for Telegram',
  minBudget: 1000,
  supportEmail: 'support@imeads.ru',
  telegram: 'https://t.me/imeads',
}

export interface Country {
  name: string
  flag: string
  reach: number
}

export const countries: Country[] = [
  { name: 'Russia', flag: '🇷🇺', reach: 85000000 },
  { name: 'Ukraine', flag: '🇺🇦', reach: 28000000 },
  { name: 'Kazakhstan', flag: '🇰🇿', reach: 12000000 },
  { name: 'Belarus', flag: '🇧🇾', reach: 6000000 },
  { name: 'Uzbekistan', flag: '🇺🇿', reach: 15000000 },
  { name: 'Kyrgyzstan', flag: '🇰🇬', reach: 3000000 },
  { name: 'Tajikistan', flag: '🇹🇯', reach: 5000000 },
  { name: 'Georgia', flag: '🇬🇪', reach: 2500000 },
  { name: 'Armenia', flag: '🇦🇲', reach: 2000000 },
  { name: 'Azerbaijan', flag: '🇦🇿', reach: 7000000 },
  { name: 'Moldova', flag: '🇲🇩', reach: 1500000 },
  { name: 'Germany', flag: '🇩🇪', reach: 18000000 },
  { name: 'USA', flag: '🇺🇸', reach: 25000000 },
  { name: 'Turkey', flag: '🇹🇷', reach: 20000000 },
  { name: 'Israel', flag: '🇮🇱', reach: 5000000 },
]

export interface Format {
  id: string
  name: string
  desc: string
  icon: string
}

export const formats: Format[] = [
  { id: 'native', name: 'Native ads', desc: 'In the Telegram feed', icon: '📰' },
  { id: 'banner', name: 'Banners', desc: 'Top / bottom block', icon: '🖼' },
  { id: 'push', name: 'Push notifications', desc: 'Direct delivery', icon: '🔔' },
  { id: 'stories', name: 'Stories', desc: 'Vertical format', icon: '📱' },
]

export interface Network {
  key: string
  name: string
  chain: string
  icon: string
  wallet: string
  colorBorder: string
  colorBg: string
  colorText: string
  colorSub: string
}

export type NetworkKey = 'trc20' | 'erc20' | 'bep20'

export const networks: Network[] = [
  {
    key: 'trc20', name: 'TRC-20', chain: 'TRON', icon: '🔴',
    wallet: 'TKZcesYejE4kex3KH73cKj2EfGgdC4i7Qw',
    colorBorder: 'border-red-500', colorBg: 'bg-red-50',
    colorText: 'text-red-700', colorSub: 'text-red-500',
  },
  {
    key: 'erc20', name: 'ERC-20', chain: 'Ethereum', icon: '🔵',
    wallet: '0x3edf8c1e5ddb5687c513a95c5abe41b19fc1ef05',
    colorBorder: 'border-blue-500', colorBg: 'bg-blue-50',
    colorText: 'text-blue-700', colorSub: 'text-blue-500',
  },
  {
    key: 'bep20', name: 'BEP-20', chain: 'BSC', icon: '🟡',
    wallet: '0x3edf8c1e5ddb5687c513a95c5abe41b19fc1ef05',
    colorBorder: 'border-yellow-500', colorBg: 'bg-yellow-50',
    colorText: 'text-yellow-700', colorSub: 'text-yellow-500',
  },
]
