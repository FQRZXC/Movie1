import { motion } from 'framer-motion'
import { ArrowUpRight, BarChart3, CreditCard, Gauge, PieChart, Play, Settings, TableProperties } from 'lucide-react'
import { dashboardMetrics } from '@/data/site'
import { cn } from '@/lib/utils'

const tabs = ['Overview', 'Campaigns', 'Audience', 'Analytics', 'Billing']
const statusBadges = ['Active', 'Paused', 'Completed']

export default function DashboardPreview() {
  return (
    <section id="dashboard" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[620px] w-[760px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Gauge className="h-3.5 w-3.5" />
            Ad Dashboard
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Everything under control
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            A convenient dashboard with analytics, a campaign table, and quick budget management — all in one interface.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ delay: 0.18, duration: 0.6 }}
          className="mx-auto mt-14 max-w-6xl overflow-hidden rounded-[28px] border border-white/10 bg-[#0b0b0e]"
        >
          <div className="flex flex-wrap items-center gap-2 border-b border-white/10 bg-white/[0.03] px-5 py-3">
            {tabs.map((tab, index) => (
              <span
                key={tab}
                className={cn(
                  'rounded-full px-4 py-2 text-xs font-medium transition',
                  index === 0 ? 'bg-white/10 text-white' : 'text-zinc-500 hover:text-zinc-300',
                )}
              >
                {tab}
              </span>
            ))}
            <span className="ml-auto flex items-center gap-2 text-xs text-zinc-500">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              Real-time data
            </span>
          </div>

          <div className="p-5 lg:p-8">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
              {dashboardMetrics.map((metric, index) => (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ delay: 0.22 + index * 0.04, duration: 0.45 }}
                  className="rounded-2xl border border-white/10 bg-white/5 p-4"
                >
                  <div className="text-[11px] uppercase tracking-widest text-zinc-500">{metric.label}</div>
                  <div className="mt-2 text-lg font-bold tracking-tight text-white">{metric.value}</div>
                </motion.div>
              ))}
            </div>

            <div className="mt-6 grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex items-center gap-3 text-xs font-medium text-zinc-500">
                  <BarChart3 className="h-4 w-4 text-indigo-400" />
                  Impressions & clicks trend
                </div>
                <div className="mt-4 grid grid-cols-7 gap-2">
                  {Array.from({ length: 28 }).map((_, index) => {
                    const height = 24 + Math.sin(index) * 12 + (index % 3) * 6
                    return (
                      <div key={index} className="flex flex-col items-center gap-2 pt-1">
                        <div className="w-full rounded-full bg-indigo-500/20" style={{ height }} />
                        <div className="text-[10px] text-zinc-600">{index + 1}</div>
                      </div>
                    )
                  })}
                </div>
              </div>

              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex items-center gap-3 text-xs font-medium text-zinc-500">
                  <PieChart className="h-4 w-4 text-indigo-400" />
                  Traffic distribution
                </div>
                <div className="mt-4 flex flex-col gap-3">
                  {[
                    { label: 'Stories', value: 38, color: 'bg-indigo-500' },
                    { label: 'Channel Feed', value: 28, color: 'bg-violet-500' },
                    { label: 'Chat List', value: 18, color: 'bg-sky-500' },
                    { label: 'Search', value: 16, color: 'bg-emerald-500' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-3">
                      <span className="h-2 w-2 rounded-full bg-white/20" />
                      <div className="w-28 text-xs text-zinc-400">{item.label}</div>
                      <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                        <div className={`h-full rounded-full ${item.color}`} style={{ width: `${item.value}%` }} />
                      </div>
                      <div className="w-8 text-right text-xs font-semibold text-white">{item.value}%</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.02]">
              <table className="min-w-[680px] border-collapse text-left text-xs text-zinc-400">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="px-5 py-3 font-semibold text-zinc-500">Campaign</th>
                    <th className="px-5 py-3 font-semibold text-zinc-500">Status</th>
                    <th className="px-5 py-3 font-semibold text-zinc-500">Impressions</th>
                    <th className="px-5 py-3 font-semibold text-zinc-500">Clicks</th>
                    <th className="px-5 py-3 font-semibold text-zinc-500">Subscribers</th>
                    <th className="px-5 py-3 font-semibold text-zinc-500">Spend</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: 'Crypto Launch', status: 0, impressions: '64 200', clicks: '812', subs: '812', spend: '$216' },
                    { name: 'Product Hunt', status: 1, impressions: '42 000', clicks: '514', subs: '514', spend: '$136' },
                    { name: 'Community Push', status: 2, impressions: '42 000', clicks: '486', subs: '486', spend: '$130' },
                  ].map((row) => (
                    <tr key={row.name} className="border-b border-white/5 last:border-0">
                      <td className="flex items-center gap-3 px-5 py-3.5 font-medium text-white">
                        <Play className="h-3.5 w-3.5 text-indigo-400" />
                        {row.name}
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={cn(
                            'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium',
                            row.status === 0 && 'bg-emerald-500/15 text-emerald-300',
                            row.status === 1 && 'bg-amber-500/15 text-amber-300',
                            row.status === 2 && 'bg-zinc-500/15 text-zinc-300',
                          )}
                        >
                          <span
                            className={cn(
                              'h-1.5 w-1.5 rounded-full',
                              row.status === 0 && 'bg-emerald-400',
                              row.status === 1 && 'bg-amber-400',
                              row.status === 2 && 'bg-zinc-400',
                            )}
                          />
                          {statusBadges[row.status]}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">{row.impressions}</td>
                      <td className="px-5 py-3.5">{row.clicks}</td>
                      <td className="px-5 py-3.5 text-white">{row.subs}</td>
                      <td className="px-5 py-3.5 text-white">{row.spend}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
