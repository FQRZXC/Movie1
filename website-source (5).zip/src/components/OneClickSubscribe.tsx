import { motion } from 'framer-motion'
import { CheckCircle2, MousePointerClick, Zap } from 'lucide-react'
import { featureHighlights } from '@/data/site'

export default function OneClickSubscribe() {
  return (
    <section id="product" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute right-0 top-1/2 h-[520px] w-[520px] -translate-y-1/2 translate-x-1/3 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-16 px-5 lg:grid-cols-[1fr_1.15fr] lg:px-8">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Zap className="h-3.5 w-3.5" />
            Key mechanic
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            A click is a subscription.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 max-w-xl text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            A user taps the ad and instantly becomes a subscriber of the target. No intermediate screens, no drop-offs, no extra actions.
          </motion.p>

          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {featureHighlights.map((item, index) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ delay: 0.18 + index * 0.06, duration: 0.45 }}
                className="glass rounded-2xl p-5 text-center transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
              >
                <div className="text-2xl font-bold tracking-tight text-white">{item.value}</div>
                <div className="mt-2 text-xs font-medium text-zinc-400">{item.label}</div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 28 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ delay: 0.18, duration: 0.7, ease: 'easeOut' }}
          className="relative"
        >
          <div className="absolute -inset-10 -z-10 rounded-[3rem] bg-indigo-500/10 blur-3xl" />
          <div className="glass overflow-hidden rounded-[32px] p-8">
            <div className="flex flex-col items-center gap-6 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-300">
                <MousePointerClick className="h-7 w-7" />
              </div>
              <div className="text-lg font-semibold text-white">Process animation</div>

              <div className="flex w-full flex-col items-center gap-3 text-sm text-zinc-300">
                <div className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3.5">Ad</div>
                <div className="flex items-center gap-2 text-zinc-500">
                  <span className="h-px w-10 bg-white/10" />
                  <span>click</span>
                  <span className="h-px w-10 bg-white/10" />
                </div>
                <div className="w-full rounded-2xl border border-indigo-500/20 bg-indigo-500/10 px-5 py-3.5 font-medium text-white">
                  Subscribed
                </div>
              </div>

              <div className="mt-2 flex items-center gap-2 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-2.5 text-sm font-medium text-emerald-300">
                <CheckCircle2 className="h-4 w-4" />
                No extra screens or drop-offs
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
