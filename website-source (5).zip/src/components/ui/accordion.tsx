import { useState, useRef, useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronDown } from 'lucide-react'

export type AccordionItem = {
  question: string
  answer: string
}

export default function Accordion({ items }: { items: AccordionItem[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <div className="flex flex-col gap-3">
      {items.map((item, index) => (
        <AccordionRow
          key={item.question}
          item={item}
          isOpen={openIndex === index}
          index={index}
          onToggle={() => setOpenIndex((current) => (current === index ? null : index))}
        />
      ))}
    </div>
  )
}

function AccordionRow({
  item,
  isOpen,
  index,
  onToggle,
}: {
  item: AccordionItem
  isOpen: boolean
  index: number
  onToggle: () => void
}) {
  const contentRef = useRef<HTMLDivElement>(null)
  const [height, setHeight] = useState(0)

  useEffect(() => {
    const node = contentRef.current
    if (!node) return
    setHeight(isOpen ? node.scrollHeight : 0)
  }, [isOpen])

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ delay: index * 0.04, duration: 0.4, ease: 'easeOut' }}
      className="glass rounded-2xl"
    >
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left text-base font-medium text-white"
        aria-expanded={isOpen}
      >
        <span className="pr-2">{item.question}</span>
        <ChevronDown
          className={`h-5 w-5 shrink-0 text-indigo-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      <div
        className="overflow-hidden transition-all duration-300 ease-out"
        style={{ maxHeight: height }}
        aria-hidden={!isOpen}
      >
        <div ref={contentRef} className="px-6 pb-6 pt-0 text-sm leading-relaxed text-zinc-400">
          {item.answer}
        </div>
      </div>
    </motion.div>
  )
}
