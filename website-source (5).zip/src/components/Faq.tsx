import { motion } from 'framer-motion'
import { HelpCircle } from 'lucide-react'
import Accordion from '@/components/ui/accordion'
import { faqItems } from '@/data/site'

export default function Faq() {
  return (
    <section id="faq" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[520px] w-[640px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <HelpCircle className="h-3.5 w-3.5" />
            FAQ
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Answers to common questions
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            We've gathered common questions about the platform, targeting, billing, and launching campaigns.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ delay: 0.16, duration: 0.5 }}
          className="mx-auto mt-14 max-w-4xl"
        >
          <Accordion items={faqItems} />
        </motion.div>
      </div>
    </section>
  )
}
