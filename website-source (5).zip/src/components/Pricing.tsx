import { motion } from 'framer-motion'
import { Crown, Rocket, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'

const tiers = [
  {
    name: 'Starter',
    price: '$0',
    period: 'no commitment',
    description: 'For a first test and quick campaign launch.',
    features: ['Self-service dashboard', 'Basic targeting', 'Real-time analytics', 'Pay per subscriber'],
    cta: 'Start for free',
    accent: false,
  },
  {
    name: 'Business',
    price: '$266',
    period: 'approximate starter package',
    description: 'For growing your audience with better support and extended capabilities.',
    features: ['All Starter features', 'Extended targeting', 'Priority moderation', 'Personal recommendations', 'Additional placements'],
    cta: 'Launch Ads',
    accent: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'for teams',
    description: 'For large budgets, product teams, and integrations.',
    features: ['Dedicated limits', 'Integrations and API', 'Priority support', 'SLA and custom terms', 'Creative assistance'],
    cta: 'Discuss terms',
    accent: false,
  },
]

export default function Pricing({ onOpenModal }: { onOpenModal: () => void }) {
  return (
    <section id="pricing" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[620px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Crown className="h-3.5 w-3.5" />
            Pricing
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Transparent pricing for any goal
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            Start with a small budget and scale. We show you a forecast before launch.
          </motion.p>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {tiers.map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: 0.18 + index * 0.08, duration: 0.5 }}
              className={cn(
                'glass relative overflow-hidden rounded-3xl p-7 transition duration-300 hover:-translate-y-1',
                tier.accent && 'border-indigo-500/30 shadow-xl shadow-indigo-500/10',
              )}
            >
              {tier.accent ? (
                <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-indigo-500/20 blur-3xl" />
              ) : null}

              <div className="relative flex items-center gap-3">
                <span
                  className={cn(
                    'inline-flex h-10 w-10 items-center justify-center rounded-2xl',
                    tier.accent ? 'bg-indigo-500 text-white' : 'bg-white/10 text-indigo-300',
                  )}
                >
                  {tier.accent ? <Rocket className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
                </span>
                <span className="text-base font-semibold text-white">{tier.name}</span>
              </div>

              <div className="relative mt-6">
                <div className="text-3xl font-bold tracking-tight text-white">{tier.price}</div>
                <div className="mt-1 text-xs text-zinc-500">{tier.period}</div>
              </div>

              <p className="relative mt-4 text-sm leading-relaxed text-zinc-400">{tier.description}</p>

              <ul className="relative mt-6 flex flex-col gap-3 text-sm text-zinc-300">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-400" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                type="button"
                onClick={tier.accent ? onOpenModal : undefined}
                className={cn(
                  'relative mt-8 w-full rounded-2xl px-5 py-3.5 text-sm font-semibold transition',
                  tier.accent
                    ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 hover:bg-indigo-400'
                    : 'border border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10 hover:text-white',
                )}
              >
                {tier.cta}
              </button>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ delay: 0.32, duration: 0.45 }}
          className="mx-auto mt-8 max-w-3xl rounded-2xl border border-white/10 bg-white/5 p-4 text-center text-xs leading-relaxed text-zinc-500"
        >
          Exact cost depends on targeting, format, and demand. The forecast updates automatically in the ad dashboard.
        </motion.div>
      </div>
    </section>
  )
}
