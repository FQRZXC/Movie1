import { useState, useEffect } from 'react'
import { useAuth } from '@/lib/auth-context'

const navItems = [
  { href: '#platform', label: 'Platform' },
  { href: '#formats', label: 'Formats' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#faq', label: 'FAQ' },
]

interface Props {
  onCampaignOpen: () => void
}

export default function Header({ onCampaignOpen }: Props) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { user, isInTelegram } = useAuth()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'backdrop-blur-xl bg-[#070b14]/80 border-b border-white/5' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <a href="/" className="flex items-center gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6d5aef] to-[#a78bfa] flex items-center justify-center text-white font-bold text-sm">iM</div>
            <span className="text-lg font-semibold text-white">imeads</span>
          </a>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <a key={item.href} href={item.href} className="px-3 py-2 text-sm text-gray-300 hover:text-white transition-colors rounded-lg hover:bg-white/5">{item.label}</a>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {user && isInTelegram ? (
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-white">
                    {user.first_name}
                    {user.last_name && ` ${user.last_name}`}
                  </div>
                  {user.username && (
                    <div className="text-xs text-gray-500">@{user.username}</div>
                  )}
                </div>
                <div className="w-9 h-9 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-sm font-bold text-indigo-400">
                  {user.first_name[0]}
                </div>
              </div>
            ) : (
              <a href="https://t.me/Imeadsrubot" target="_blank" rel="noopener noreferrer" className="px-4 py-2 text-sm text-gray-300 hover:text-white border border-white/10 rounded-lg hover:border-white/20 transition-all flex items-center gap-2">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                </svg>
                Login via Telegram
              </a>
            )}
            <button onClick={onCampaignOpen} className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-[#6d5aef] to-[#7c3aed] rounded-lg hover:opacity-90 transition-opacity">Launch Ads</button>
          </div>

          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2 text-gray-300 hover:text-white" aria-label="Open menu">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={mobileOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'} />
            </svg>
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden backdrop-blur-xl bg-[#070b14]/95 border-t border-white/5">
          <div className="px-4 py-4 space-y-1">
            {navItems.map((item) => (
              <a key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className="block px-3 py-2.5 text-sm text-gray-300 hover:text-white rounded-lg hover:bg-white/5 transition-colors">{item.label}</a>
            ))}
            <div className="pt-3 border-t border-white/5 space-y-2">
              {user && isInTelegram ? (
                <div className="px-3 py-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-sm font-bold text-indigo-400">
                      {user.first_name[0]}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">
                        {user.first_name}
                        {user.last_name && ` ${user.last_name}`}
                      </div>
                      {user.username && (
                        <div className="text-xs text-gray-500">@{user.username}</div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <a href="https://t.me/Imeadsrubot" target="_blank" rel="noopener noreferrer" className="block w-full text-left px-3 py-2.5 text-sm text-gray-300 hover:text-white border border-white/10 rounded-lg flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                  </svg>
                  Login via Telegram
                </a>
              )}
              <button onClick={() => { onCampaignOpen(); setMobileOpen(false) }} className="block w-full px-4 py-2.5 text-sm font-medium text-white bg-gradient-to-r from-[#6d5aef] to-[#7c3aed] rounded-lg text-center hover:opacity-90 transition-opacity">Launch Ads</button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
