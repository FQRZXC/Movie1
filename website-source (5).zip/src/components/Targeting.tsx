import { useState } from 'react'
import { motion } from 'framer-motion'
import { Target } from 'lucide-react'
import { defaultTargeting } from '@/data/site'
import { formatCurrency, formatNumber } from '@/lib/format'

const countries = ['USA', 'Germany', 'UK', 'Kazakhstan', 'Uzbekistan']
const languages = ['English', 'German', 'Russian', 'Turkish']
const platforms = ['iOS', 'Android', 'Desktop']
const audienceTypes = ['All', 'Premium', 'Crypto', 'Premium + Crypto']
const categories = ['Finance', 'Crypto', 'Technology', 'Marketing', 'Gaming']

export default function Targeting() {
  const [country, setCountry] = useState(defaultTargeting.country)
  const [language, setLanguage] = useState(defaultTargeting.language)
  const [platform, setPlatform] = useState(defaultTargeting.platform)
  const [audience, setAudience] = useState(defaultTargeting.audience)
  const [selectedCategories, setSelectedCategories] = useState<string[]>(defaultTargeting.categories)

  const toggleCategory = (value: string) => {
    setSelectedCategories((current) =>
      current.includes(value) ? current.filter((item) => item !== value) : [...current, value],
    )
  }

  const estimated = {
    audience: defaultTargeting.estimated.audience,
    cpm: defaultTargeting.estimated.cpm,
    reach: defaultTargeting.estimated.reach,
  }

  return (
    <section className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute right-0 top-1/2 h-[560px] w-[580px] -translate-y-1/2 translate-x-1/3 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Target className="h-3.5 w-3.5" />
            Audience setup
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Choose your precise audience
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            Filter by country, language, platform, and interests — and get an accurate forecast before launching a campaign.
          </motion.p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.16, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="text-xs font-semibold uppercase tracking-widest text-zinc-500">Audience Filters</div>

            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <SelectField label="Country" value={country} onChange={setCountry} options={countries} />
              <SelectField label="Language" value={language} onChange={setLanguage} options={languages} />
              <SelectField label="Platform" value={platform} onChange={setPlatform} options={platforms} />
              <SelectField label="Audience type" value={audience} onChange={setAudience} options={audienceTypes} />
            </div>

            <div className="mt-6">
              <div className="text-xs font-medium text-zinc-400">Categories</div>
              <div className="mt-3 flex flex-wrap gap-2">
                {categories.map((item) => {
                  const active = selectedCategories.includes(item)
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleCategory(item)}
                      className={`rounded-full border px-4 py-2 text-xs font-medium transition ${
                        active
                          ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-300'
                          : 'border-white/10 bg-white/5 text-zinc-400 hover:border-white/20 hover:text-zinc-200'
                      }`}
                    >
                      {item}
                    </button>
                  )
                })}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.24, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="text-xs font-semibold uppercase tracking-widest text-indigo-400">Forecast</div>
            <div className="mt-6 flex flex-col gap-4">
              <PreviewRow title="Country" value={country} />
              <PreviewRow title="Language" value={language} />
              <PreviewRow title="Platform" value={platform} />
              <PreviewRow title="Audience" value={audience} />
              <PreviewRow title="Categories" value={selectedCategories.join(', ') || '—'} />
            </div>

            <div className="mt-8 grid grid-cols-1 gap-3">
              <MetricPill label="Estimated audience" value={formatNumber(estimated.audience)} />
              <MetricPill label="Estimated CPM" value={formatCurrency(estimated.cpm)} />
              <MetricPill label="Estimated reach" value={formatNumber(estimated.reach)} />
            </div>

            <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4 text-xs leading-relaxed text-zinc-500">
              The forecast updates in real time as you change filters and helps you estimate the budget before launch.
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value: string
  onChange: (value: string) => void
  options: string[]
}) {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-xs font-medium text-zinc-400">{label}</label>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none transition focus:border-indigo-500/40 focus:ring-2 focus:ring-indigo-500/20"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  )
}

function PreviewRow({ title, value }: { title: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
      <div className="text-xs text-zinc-400">{title}</div>
      <div className="text-sm font-medium text-white">{value}</div>
    </div>
  )
}

function MetricPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-indigo-500/20 bg-indigo-500/10 px-4 py-3.5">
      <div className="text-[11px] uppercase tracking-widest text-indigo-300/80">{label}</div>
      <div className="mt-1.5 text-lg font-bold tracking-tight text-white">{value}</div>
    </div>
  )
}
