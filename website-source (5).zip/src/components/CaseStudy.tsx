import { motion } from 'framer-motion'
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from 'recharts'
import { Flame } from 'lucide-react'
import { caseStudy } from '@/data/site'
import { formatNumber } from '@/lib/format'

const chartData = [
  { name: 'Spestra', value: caseStudy.comparison.platform },
  { name: 'Traditional', value: caseStudy.comparison.traditional },
]

export default function CaseStudy() {
  return (
    <section id="cases" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[560px] w-[680px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Flame className="h-3.5 w-3.5" />
            Case Study
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            {caseStudy.title}
          </motion.h2>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ delay: 0.16, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {caseStudy.stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ delay: 0.18 + index * 0.04, duration: 0.45 }}
                  className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center"
                >
                  <div className="text-[11px] uppercase tracking-widest text-zinc-500">{stat.label}</div>
                  <div className="mt-2 text-xl font-bold tracking-tight text-white">{stat.value}</div>
                </motion.div>
              ))}
            </div>

            <div className="mt-8 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-5 text-center text-sm text-emerald-300">
              +{formatNumber(caseStudy.comparison.delta)} additional subscribers compared to the traditional model
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ delay: 0.24, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="text-xs font-semibold uppercase tracking-widest text-zinc-500">Result comparison</div>
            <div className="mt-6 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} barCategoryGap="32%">
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                  <XAxis dataKey="name" tick={{ fill: '#a1a1aa', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#a1a1aa', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    cursor={{ fill: 'rgba(255,255,255,0.04)' }}
                    contentStyle={{
                      background: '#18181b',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: 16,
                      color: '#f9fafb',
                    }}
                    formatter={(value: number) => [formatNumber(value), 'Subscribers']}
                  />
                  <Bar dataKey="value" radius={[14, 14, 0, 0]} fill="#4f46e5" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3 text-center text-xs text-zinc-400">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5">
                <div className="text-indigo-400">Spestra</div>
                <div className="mt-1 text-lg font-bold text-white">{formatNumber(caseStudy.comparison.platform)}</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5">
                <div className="text-zinc-400">Traditional</div>
                <div className="mt-1 text-lg font-bold text-white">{formatNumber(caseStudy.comparison.traditional)}</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
