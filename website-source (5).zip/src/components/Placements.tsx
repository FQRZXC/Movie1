import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Layers } from 'lucide-react'
import { placements } from '@/data/site'
import { cn } from '@/lib/utils'

export default function Placements() {
  const [activeId, setActiveId] = useState(placements[0].id)
  const active = placements.find((item) => item.id === activeId) ?? placements[0]

  return (
    <section className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-0 h-[520px] w-[680px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Layers className="h-3.5 w-3.5" />
            Ad Placements
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Six placements. One messenger.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            Choose the placement that fits your campaign goal, from quick reach to precise contact with an engaged audience.
          </motion.p>
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-[minmax(0,0.78fr)_minmax(0,1.22fr)]">
          <div className="flex flex-col gap-2 overflow-x-auto pb-1 sm:flex-row lg:flex-col lg:overflow-visible lg:pb-0">
            {placements.map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, x: -18 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ delay: 0.12 + index * 0.04, duration: 0.45 }}
                type="button"
                onClick={() => setActiveId(item.id)}
                className={cn(
                  'flex w-full shrink-0 items-center gap-4 rounded-2xl border px-5 py-4 text-left transition duration-200 lg:w-auto',
                  activeId === item.id
                    ? 'border-indigo-500/30 bg-indigo-500/10 shadow-lg shadow-indigo-500/10'
                    : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/[0.06]',
                )}
              >
                <span
                  className={cn(
                    'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-xs font-bold',
                    activeId === item.id ? 'bg-indigo-500 text-white' : 'bg-white/10 text-zinc-300',
                  )}
                >
                  {String(index + 1).padStart(2, '0')}
                </span>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">{item.title}</div>
                  <div className="mt-0.5 line-clamp-1 text-xs text-zinc-400">{item.description}</div>
                </div>
              </motion.button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={active.id}
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -18 }}
              transition={{ duration: 0.4 }}
              className="glass relative overflow-hidden rounded-[28px] p-8"
            >
              <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full bg-indigo-500/15 blur-3xl" />
              <div className="relative mb-6 inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300">
                <span className="h-1.5 w-1.5 rounded-full bg-indigo-400" />
                {active.format}
              </div>

              <div className="relative flex flex-col gap-6 lg:flex-row lg:items-start lg:gap-10">
                <div className="flex-1">
                  <div className="text-lg font-semibold text-white">{active.title}</div>
                  <p className="mt-3 text-sm leading-relaxed text-zinc-400">{active.description}</p>

                  <div className="mt-6 grid grid-cols-2 gap-3">
                    <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5">
                      <div className="text-[11px] uppercase tracking-widest text-zinc-500">Reach</div>
                      <div className="mt-1.5 text-sm font-semibold text-white">{active.reach}</div>
                    </div>
                    <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5">
                      <div className="text-[11px] uppercase tracking-widest text-zinc-500">Format</div>
                      <div className="mt-1.5 text-sm font-semibold text-white">{active.format}</div>
                    </div>
                  </div>

                  <div className="mt-6 flex items-center gap-3">
                    <button
                      type="button"
                      className="rounded-full bg-indigo-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400"
                    >
                      Select Placement
                    </button>
                    <button
                      type="button"
                      className="rounded-full border border-white/10 bg-white/5 px-5 py-2.5 text-sm font-medium text-zinc-300 transition hover:bg-white/10 hover:text-white"
                    >
                      Learn More
                    </button>
                  </div>
                </div>

                <div className="w-full flex-1 rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
                  <div className="mb-3 flex items-center gap-2 text-xs font-medium text-zinc-500">
                    <span className="h-2 w-2 rounded-full bg-emerald-400" />
                    Preview
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-[#0b0b0e] p-4">
                    <div className="mb-4 flex items-center gap-2 text-xs text-zinc-500">
                      <span className="h-2 w-2 rounded-full bg-zinc-700" />
                      <span className="h-2 w-2 rounded-full bg-zinc-700" />
                      <span className="h-2 w-2 rounded-full bg-zinc-700" />
                      <span className="ml-auto">{active.title}</span>
                    </div>
                    <div className="flex flex-col gap-3">
                      <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-xs text-zinc-400">
                        Publication header
                      </div>
                      <div className="rounded-xl border border-indigo-500/20 bg-indigo-500/10 p-3 text-xs font-medium text-indigo-200">
                        Sponsored post
                      </div>
                      <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-xs text-zinc-400">
                        Another feed post
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
