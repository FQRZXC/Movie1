import { motion } from 'framer-motion'
import { Banknote, Coins, CreditCard, Smartphone } from 'lucide-react'
import { paymentMethods } from '@/data/site'
import { cn } from '@/lib/utils'

const icons = [Coins, CreditCard, Smartphone]

export default function Payment() {
  return (
    <section className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[520px] w-[640px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Banknote className="h-3.5 w-3.5" />
            Payment methods
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Top up with your preferred currency
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            Choose the payment method that works best for you and start with no delays.
          </motion.p>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {paymentMethods.map((item, index) => {
            const Icon = icons[index] ?? Banknote
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ delay: 0.16 + index * 0.06, duration: 0.45 }}
                className="glass group relative overflow-hidden rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
              >
                <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-indigo-500/10 blur-2xl opacity-60 transition group-hover:opacity-100" />
                <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-300">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="mt-5 text-base font-semibold text-white">{item.title}</div>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{item.description}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {item.tags.map((tag) => (
                    <span key={tag} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-zinc-300">
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            )
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ delay: 0.28, duration: 0.45 }}
          className="mx-auto mt-8 max-w-3xl rounded-2xl border border-white/10 bg-white/5 p-4 text-center text-xs leading-relaxed text-zinc-500"
        >
          Bonuses and cashback are available when topping up with in-platform currency. Terms are updated in the ad dashboard.
        </motion.div>
      </div>
    </section>
  )
}
