import { motion } from 'framer-motion'
import { Bookmark, CheckCircle2, CreditCard, LineChart, Rocket, UserPlus } from 'lucide-react'
import { howItWorksSteps } from '@/data/site'

const icons = [Bookmark, CreditCard, UserPlus, Rocket]

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[520px] w-[680px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <LineChart className="h-3.5 w-3.5" />
            Getting started
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Four steps to results
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            Minimal steps from entering the platform to your first subscribers. Everything is transparent from the start.
          </motion.p>
        </div>

        <div className="mx-auto mt-14 grid max-w-5xl grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {howItWorksSteps.map((step, index) => {
            const Icon = icons[index] ?? CheckCircle2
            return (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ delay: 0.18 + index * 0.08, duration: 0.5 }}
                className="glass group relative overflow-hidden rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
              >
                <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-indigo-500/10 blur-2xl opacity-60 transition group-hover:opacity-100" />
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500 text-xs font-bold text-white shadow-lg shadow-indigo-500/25">
                    {step.step}
                  </span>
                  <Icon className="h-5 w-5 text-indigo-300" />
                </div>
                <div className="mt-5 text-base font-semibold text-white">{step.title}</div>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{step.description}</p>

                <div className="mt-5 rounded-2xl border border-white/10 bg-white/5 p-3 text-[11px] uppercase tracking-widest text-zinc-500">
                  mini preview
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
