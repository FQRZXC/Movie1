import { motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import { brand } from '@/data/site'
import HeroVisual from '@/components/HeroVisual'

export default function Hero({ onOpenModal }: { onOpenModal: () => void }) {
  return (
    <section className="relative overflow-hidden pt-28 pb-8 lg:pt-36 lg:pb-0">
      <div className="absolute left-1/2 top-0 h-[520px] w-[760px] -translate-x-1/2 -translate-y-1/3 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 pt-8 lg:grid-cols-[1.05fr_1fr] lg:px-8">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Advertising platform
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08, duration: 0.6 }}
            className="mt-6 max-w-2xl text-4xl font-bold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-[3.4rem]"
          >
            Grow your audience in messengers in one click
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.16, duration: 0.6 }}
            className="mt-6 max-w-xl text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            {brand.description}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.24, duration: 0.6 }}
            className="mt-8 flex flex-col gap-3 sm:flex-row"
          >
            <button
              type="button"
              onClick={onOpenModal}
              className="inline-flex items-center justify-center gap-2 rounded-full bg-indigo-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400 hover:shadow-indigo-500/30"
            >
              Launch Ads
            </button>
            <a
              href="#how-it-works"
              className="inline-flex items-center justify-center rounded-full border border-white/10 bg-white/5 px-7 py-3.5 text-sm font-medium text-zinc-300 transition hover:bg-white/10 hover:text-white"
            >
              How It Works
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.42, duration: 0.6 }}
            className="mt-8 flex items-center gap-4 text-xs text-zinc-600"
          >
            <span className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              No complex integration
            </span>
            <span className="h-3 w-px bg-white/10" />
            Transparent analytics
          </motion.div>
        </div>

        <HeroVisual />
      </div>
    </section>
  )
}
