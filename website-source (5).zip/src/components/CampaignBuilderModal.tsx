import { useState, useMemo, useEffect, useCallback } from 'react'
import { config, countries, formats, networks, type Network, type NetworkKey } from '@/config'

interface Props {
  open: boolean
  onClose: () => void
}

type Step = 1 | 2 | 3 | 4 | 5 | 6 | 7

function useTimer(seconds: number, active: boolean) {
  const [remaining, setRemaining] = useState(seconds)
  useEffect(() => {
    if (!active) { setRemaining(seconds); return }
    const id = setInterval(() => setRemaining((r) => (r > 0 ? r - 1 : 0)), 1000)
    return () => clearInterval(id)
  }, [active, seconds])
  const mm = String(Math.floor(remaining / 60)).padStart(2, '0')
  const ss = String(remaining % 60).padStart(2, '0')
  return { mm, ss, expired: remaining === 0, total: seconds, remaining }
}

export default function CampaignBuilderModal({ open, onClose }: Props) {
  const [step, setStep] = useState<Step>(1)
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [selectedGeo, setSelectedGeo] = useState<string[]>([])
  const [selectedFormat, setSelectedFormat] = useState('')
  const [budget, setBudget] = useState('')
  const [selectedNetwork, setSelectedNetwork] = useState<NetworkKey>('trc20')
  const [submitting, setSubmitting] = useState(false)
  const [geoSearch, setGeoSearch] = useState('')
  const [copied, setCopied] = useState(false)
  const [campaignId, setCampaignId] = useState<string | null>(null)

  const activeNetwork: Network = networks.find((n) => n.key === selectedNetwork) ?? networks[0]
  const timer = useTimer(3600, step === 7)

  const totalReach = useMemo(() => {
    return countries.filter((c) => selectedGeo.includes(c.name)).reduce((sum, c) => sum + c.reach, 0)
  }, [selectedGeo])

  const filteredGeo = countries.filter((c) => c.name.toLowerCase().includes(geoSearch.toLowerCase()) && !selectedGeo.includes(c.name))

  const toggleGeo = (country: string) => {
    setSelectedGeo((prev) => (prev.includes(country) ? prev.filter((g) => g !== country) : [...prev, country]))
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(activeNetwork.wallet)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleClose = useCallback(() => {
    setStep(1)
    setName('')
    setUrl('')
    setSelectedGeo([])
    setSelectedFormat('')
    setBudget('')
    setSelectedNetwork('trc20')
    setCopied(false)
    setCampaignId(null)
    onClose()
  }, [onClose])

  const canNext = () => {
    if (step === 1) return name.trim().length > 0
    if (step === 2) return selectedGeo.length > 0
    if (step === 3) return selectedFormat.length > 0
    if (step === 4) return Number(budget) >= config.minBudget
    return true
  }

  const handleCreate = async () => {
    setSubmitting(true)
    try {
      const fmt = formats.find((f) => f.id === selectedFormat)
      const { db } = await import('@lork/sdk')
      const { data, error } = await db.from('campaigns').insert({
        name,
        url: url || null,
        geo: selectedGeo,
        format: fmt?.name ?? selectedFormat,
        budget: Number(budget),
        status: 'pending_payment',
        network: activeNetwork.key,
        impressions: 0,
        clicks: 0,
        spent: 0,
      }).select('id').single()
      if (!error && data) setCampaignId(data.id)
    } catch {
      // offline — just show the waiting screen
    } finally {
      setSubmitting(false)
      setStep(7)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" onClick={handleClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div className="relative w-full max-w-lg bg-white rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <button onClick={handleClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h3 className="text-2xl font-bold text-gray-900 mb-5">Create Campaign</h3>

        {step <= 5 && (
          <div className="flex items-center gap-1 mb-8">
            {[1, 2, 3, 4, 5].map((s, i) => (
              <div key={s} className="flex items-center flex-1">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold shrink-0 transition-colors ${s <= step ? 'bg-[#6d5aef] text-white' : 'bg-gray-200 text-gray-500'}`}>
                  {s < step ? <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg> : s}
                </div>
                {i < 4 && <div className={`flex-1 h-0.5 mx-1 ${s < step ? 'bg-[#6d5aef]' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Campaign name *</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Channel promotion"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6d5aef] focus:border-transparent text-sm transition-all" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Promotion URL</label>
              <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://t.me/your_channel"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6d5aef] focus:border-transparent text-sm transition-all" />
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Geography</div>
            <div className="bg-blue-50 rounded-xl p-4 mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" /></svg>
                <span className="text-sm font-medium text-gray-700">Total Reach</span>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-gray-900">{totalReach.toLocaleString()}</div>
                <div className="text-xs text-gray-500">users / day</div>
              </div>
            </div>
            <input value={geoSearch} onChange={(e) => setGeoSearch(e.target.value)} placeholder="Search country..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6d5aef] focus:border-transparent text-sm mb-4 transition-all" />
            {selectedGeo.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedGeo.map((g) => {
                  const country = countries.find((c) => c.name === g)
                  return (
                    <button key={g} onClick={() => toggleGeo(g)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#6d5aef]/10 text-[#6d5aef] text-xs font-medium border border-[#6d5aef]/20">
                      <span>{country?.flag}</span> {g} <span className="text-[#6d5aef]/60">×</span>
                    </button>
                  )
                })}
              </div>
            )}
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {filteredGeo.map((c) => (
                <button key={c.name} onClick={() => toggleGeo(c.name)}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-gray-100 hover:border-[#6d5aef]/30 hover:bg-gray-50 transition-all text-left">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{c.flag}</span>
                    <span className="text-sm font-medium text-gray-900">{c.name}</span>
                  </div>
                  <span className="text-xs text-gray-500 font-mono">{c.reach.toLocaleString()}/day</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Format</div>
            {formats.map((f) => (
              <button key={f.id} onClick={() => setSelectedFormat(f.id)}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all ${selectedFormat === f.id ? 'border-[#6d5aef] bg-[#6d5aef]/5' : 'border-gray-100 hover:border-gray-200 bg-white'}`}>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{f.icon}</span>
                  <div>
                    <div className="text-sm font-semibold text-gray-900">{f.name}</div>
                    <div className="text-xs text-gray-500">{f.desc}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Budget</div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Amount ($) *</label>
              <input type="number" value={budget} onChange={(e) => setBudget(e.target.value)} placeholder={String(config.minBudget)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6d5aef] focus:border-transparent text-sm transition-all" />
              <p className="text-xs text-gray-400 mt-1">Minimum: ${config.minBudget.toLocaleString()}</p>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[10000, 15000, 25000, 50000, 100000].map((v) => (
                <button key={v} onClick={() => setBudget(String(v))}
                  className={`py-2.5 rounded-xl text-sm font-medium border transition-all ${Number(budget) === v ? 'border-[#6d5aef] bg-[#6d5aef] text-white' : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'}`}>
                  ${v >= 1000 ? `${v / 1000}K` : v}
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 5 && (
          <div className="space-y-3">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Review</div>
            {[
              ['Campaign', name],
              ['URL', url || '—'],
              ['Geo', selectedGeo.join(', ')],
              ['Format', formats.find((f) => f.id === selectedFormat)?.name ?? selectedFormat],
              ['Budget', `$${Number(budget).toLocaleString()}`],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between items-center py-2.5 border-b border-gray-100">
                <span className="text-sm text-gray-500">{label}</span>
                <span className="text-sm font-medium text-gray-900">{value}</span>
              </div>
            ))}
          </div>
        )}

        {step === 6 && (
          <div className="space-y-3">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Payment</div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Network</label>
              <div className="grid grid-cols-2 gap-2">
                {networks.map((net) => (
                  <button key={net.key}
                    onClick={() => { setSelectedNetwork(net.key as NetworkKey); setCopied(false) }}
                    className={`relative p-3 rounded-xl border-2 transition-all text-left ${selectedNetwork === net.key ? `${net.colorBorder} ${net.colorBg}` : 'border-gray-200 hover:border-gray-300 bg-white'}`}>
                    {selectedNetwork === net.key && (
                      <div className="absolute top-2 right-2"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg></div>
                    )}
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-lg">{net.icon}</span>
                      <span className={`text-sm font-semibold ${selectedNetwork === net.key ? net.colorText : 'text-gray-900'}`}>{net.name}</span>
                    </div>
                    <div className={`text-xs ${selectedNetwork === net.key ? net.colorSub : 'text-gray-500'}`}>{net.chain}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="border border-gray-200 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-500">Amount due</span>
                <div className="flex items-center gap-1">
                  <span className="text-2xl font-bold text-gray-900">${Number(budget).toLocaleString()}</span>
                  <span className="text-sm text-gray-400 ml-1">USDT</span>
                </div>
              </div>
              <div className="text-xs text-gray-500 mb-1.5">Payment address ({activeNetwork.name})</div>
              <div className="flex items-center gap-2">
                <div className="flex-1 px-3 py-2.5 rounded-lg bg-gray-50 border border-gray-200 text-sm text-gray-700 font-mono truncate">{activeNetwork.wallet}</div>
                <button onClick={handleCopy} className="shrink-0 p-2.5 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  {copied ? <svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    : <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>}
                </button>
              </div>
            </div>

            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
              <div className="flex gap-2">
                <svg className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                <div>
                  <div className="text-sm font-semibold text-amber-700">Important</div>
                  <div className="text-xs text-amber-600 mt-1 leading-relaxed">
                    Send USDT <strong>only through the {activeNetwork.chain} ({activeNetwork.name}) network</strong>. Transfers via other networks may be irreversibly lost.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 7 && (
          <div className="space-y-5">
            <div className="flex flex-col items-center py-6">
              {/* Timer */}
              <div className="relative w-28 h-28 mb-5">
                <svg className="w-28 h-28 -rotate-90" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="52" fill="none" stroke="#e5e7eb" strokeWidth="6" />
                  <circle cx="60" cy="60" r="52" fill="none" stroke="#6d5aef" strokeWidth="6"
                    strokeDasharray={2 * Math.PI * 52}
                    strokeDashoffset={2 * Math.PI * 52 * (1 - timer.remaining / timer.total)}
                    strokeLinecap="round" className="transition-all duration-1000" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900 tabular-nums">{timer.mm}:{timer.ss}</span>
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider">remaining</span>
                </div>
              </div>

              <h4 className="text-xl font-bold text-gray-900 mb-2">
                {timer.expired ? 'Payment expired' : 'Payment waiting'}
              </h4>
              <p className="text-sm text-gray-500 text-center leading-relaxed max-w-xs mb-4">
                {timer.expired
                  ? 'Payment expired. Create a new campaign.'
                  : 'Send USDT to the address above. The campaign will activate automatically after the transaction is confirmed in the network.'
                }
              </p>

              {/* Amount */}
              <div className="w-full bg-gray-50 rounded-xl p-4 mb-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Amount</span>
                  <span className="text-lg font-bold text-gray-900">${Number(budget).toLocaleString()} USDT</span>
                </div>
              </div>

              {/* Address */}
              <div className="w-full bg-gray-50 rounded-xl p-4 mb-3">
                <div className="text-xs text-gray-500 mb-1.5">Address ({activeNetwork.name})</div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 text-xs text-gray-700 font-mono truncate">{activeNetwork.wallet}</div>
                  <button onClick={handleCopy} className="shrink-0 p-2 rounded-lg border border-gray-200 hover:bg-white transition-colors">
                    {copied
                      ? <svg className="w-3.5 h-3.5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                      : <svg className="w-3.5 h-3.5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>}
                  </button>
                </div>
              </div>

              {/* Status */}
              <div className={`w-full rounded-xl p-4 flex items-center gap-3 ${timer.expired ? 'bg-red-50 border border-red-200' : 'bg-amber-50 border border-amber-200'}`}>
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${timer.expired ? 'bg-red-500' : 'bg-amber-500 animate-pulse'}`} />
                <span className={`text-sm font-medium ${timer.expired ? 'text-red-700' : 'text-amber-700'}`}>
                  {timer.expired ? 'Payment expired' : `Waiting for transaction confirmation in ${activeNetwork.chain} network`}
                </span>
              </div>
            </div>
          </div>
        )}

        {step <= 5 && (
          <div className="flex gap-3 mt-6">
            {step > 1 && <button onClick={() => setStep((s) => (s - 1) as Step)} className="flex-1 py-3 rounded-xl border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 transition-colors">Back</button>}
            <button onClick={() => setStep((s) => (s + 1) as Step)} disabled={!canNext()}
              className="flex-1 py-3 rounded-xl bg-[#6d5aef] text-white text-sm font-medium hover:bg-[#5b47db] transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
              {step === 5 ? 'Go to Payment' : 'Next'}
            </button>
          </div>
        )}

        {step === 6 && (
          <button onClick={handleCreate} disabled={submitting}
            className="w-full mt-6 py-3 rounded-xl bg-[#6d5aef] text-white text-sm font-medium hover:bg-[#5b47db] transition-colors disabled:opacity-40">
            {submitting ? 'Creating...' : 'Confirm & Create'}
          </button>
        )}

        {step === 7 && (
          <button onClick={handleClose} className="w-full mt-4 py-3 rounded-xl border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 transition-colors">
            {timer.expired ? 'Create New' : 'Close'}
          </button>
        )}
      </div>
    </div>
  )
}
