import { motion } from 'framer-motion'
import { CheckCircle2, Globe, Settings, Rocket, ShieldCheck, Sparkles, Wallet } from 'lucide-react'
import { advantages } from '@/data/site'
import { cn } from '@/lib/utils'

const icons = [Sparkles, Wallet, Globe, Settings, ShieldCheck, Rocket]

export default function Advantages() {
  return (
    <section id="advantages" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[560px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Why choose us
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            We make messenger advertising transparent, fast, and convenient — from your first click to scaling campaigns.
          </motion.p>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {advantages.map((item, index) => {
            const Icon = icons[index] ?? CheckCircle2
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ delay: 0.12 + index * 0.04, duration: 0.45 }}
                className="glass group relative overflow-hidden rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
              >
                <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-indigo-500/10 blur-2xl opacity-60 transition group-hover:opacity-100" />
                <div
                  className={cn(
                    'mb-5 inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-300 transition',
                    'group-hover:bg-indigo-500 group-hover:text-white',
                  )}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <div className="text-base font-semibold text-white">{item.title}</div>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{item.description}</p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
