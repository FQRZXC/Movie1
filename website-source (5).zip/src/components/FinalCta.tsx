import { motion } from 'framer-motion'
import { MessageSquare, Rocket, ShieldCheck, Zap } from 'lucide-react'

export default function FinalCta({ onOpenModal }: { onOpenModal: () => void }) {
  return (
    <section id="cta" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute inset-x-0 bottom-0 h-[560px] bg-gradient-to-t from-indigo-500/10 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
          className="glass relative overflow-hidden rounded-[32px] px-8 py-16 text-center lg:px-20 lg:py-20"
        >
          <div className="absolute -left-16 top-1/2 h-64 w-64 -translate-y-1/2 rounded-full bg-indigo-500/15 blur-3xl" />
          <div className="absolute -right-16 top-1/2 h-64 w-64 -translate-y-1/2 rounded-full bg-violet-500/10 blur-3xl" />

          <div className="relative">
            <motion.h2
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: 0.08, duration: 0.5 }}
              className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
            >
              Launch your first campaign today
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: 0.14, duration: 0.5 }}
              className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-zinc-400 lg:text-lg"
            >
              Start with a small budget, measure results, and scale what works.
            </motion.p>

            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                type="button"
                onClick={onOpenModal}
                className="inline-flex items-center gap-2 rounded-full bg-indigo-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400 hover:shadow-indigo-500/30"
              >
                <Rocket className="h-4 w-4" />
                Launch Ads
              </button>
              <button
                type="button"
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-7 py-3.5 text-sm font-medium text-zinc-300 transition hover:bg-white/10 hover:text-white"
              >
                <MessageSquare className="h-4 w-4" />
                Contact Sales
              </button>
            </div>

            <div className="mx-auto mt-10 flex max-w-xl flex-col items-center justify-center gap-4 text-xs text-zinc-500 sm:flex-row">
              <span className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-indigo-400" />
                Self-service
              </span>
              <span className="hidden h-3 w-px bg-white/10 sm:block" />
              <span className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-indigo-400" />
                Fast moderation
              </span>
              <span className="hidden h-3 w-px bg-white/10 sm:block" />
              <span className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-indigo-400" />
                Flexible payments
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
