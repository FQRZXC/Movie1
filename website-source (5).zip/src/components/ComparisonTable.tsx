import { motion } from 'framer-motion'
import { comparisonRows } from '@/data/site'
import { cn } from '@/lib/utils'

const columns = ['criteria', 'platform', 'telegram', 'other'] as const

const headers: Record<(typeof columns)[number], string> = {
  criteria: 'Criterion',
  platform: 'imeads',
  telegram: 'Telegram Ads',
  other: 'Other networks',
}

export default function ComparisonTable() {
  return (
    <section className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-0 h-[520px] w-[640px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            Comparing approaches
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            See the difference at a glance: from onboarding and targeting to final conversion and payment methods.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ delay: 0.16, duration: 0.5 }}
          className="mx-auto mt-14 max-w-5xl overflow-x-auto rounded-3xl border border-white/10 bg-white/[0.03] pb-2"
        >
          <table className="min-w-[840px] border-collapse text-left text-sm text-zinc-300">
            <thead>
              <tr className="border-b border-white/10">
                {columns.map((col) => (
                  <th
                    key={col}
                    className={cn(
                      'px-6 py-4 text-xs font-semibold uppercase tracking-widest text-zinc-500',
                      col === 'platform' && 'text-indigo-400',
                    )}
                  >
                    {headers[col]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparisonRows.map((row, index) => (
                <motion.tr
                  key={row.label}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ delay: 0.18 + index * 0.03, duration: 0.45 }}
                  className="border-b border-white/5 last:border-0"
                >
                  <td className="px-6 py-4 font-medium text-white">{row.label}</td>
                  <td className="px-6 py-4 text-indigo-200">{row.platform}</td>
                  <td className="px-6 py-4 text-zinc-400">{row.telegram}</td>
                  <td className="px-6 py-4 text-zinc-400">{row.other}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </section>
  )
}
