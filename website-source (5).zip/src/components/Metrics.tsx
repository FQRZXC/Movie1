import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import useCountUp from '@/hooks/useCountUp'
import { metrics } from '@/data/site'
import { formatNumber } from '@/lib/format'

function parseMetricValue(raw: string) {
  const numeric = raw.replace(/[^0-9.]/g, '')
  if (!numeric) return 0
  const value = Number.parseFloat(numeric)
  return Number.isFinite(value) ? value : 0
}

export default function Metrics() {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-16 lg:py-20">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-5 sm:grid-cols-3 lg:grid-cols-5 lg:px-8">
        {metrics.map((item, index) => (
          <MetricCard key={item.label} item={item} index={index} active={inView} />
        ))}
      </div>
    </section>
  )
}

function MetricCard({
  item,
  index,
  active,
}: {
  item: (typeof metrics)[number]
  index: number
  active: boolean
}) {
  const numeric = parseMetricValue(item.value)
  const count = useCountUp(numeric, { active })
  const suffix = item.value.replace(/[0-9.]/g, '')

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ delay: index * 0.06, duration: 0.45, ease: 'easeOut' }}
      className="glass group relative overflow-hidden rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
    >
      <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-indigo-500/10 blur-2xl transition group-hover:opacity-100 opacity-60" />
      <div className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
        {formatNumber(count)}
        {suffix}
      </div>
      <div className="mt-1 text-xs font-medium uppercase tracking-widest text-indigo-400">{item.label}</div>
      <div className="mt-2 text-xs leading-relaxed text-zinc-500">{item.description}</div>
    </motion.div>
  )
}
