import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import { cn } from '@/lib/utils'

const steps = [
  { title: 'Select campaign type', description: 'Channel, bot, or mini application.' },
  { title: 'Add destination', description: 'Enter a link or technical goal for the campaign.' },
  { title: 'Set up audience', description: 'Country, language, platform, and interests.' },
  { title: 'Set budget', description: 'Define a starting limit and a per-result limit.' },
  { title: 'Upload creative', description: 'Add headline, description, and visual.' },
  { title: 'Review campaign', description: 'Check settings and start serving.' },
]

export default function OnboardingModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [step, setStep] = useState(0)

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-5 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 24 }}
            transition={{ duration: 0.25 }}
            className="glass w-full max-w-xl overflow-hidden rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 px-6 py-5">
              <div>
                <div className="text-base font-semibold text-white">Launch Ads</div>
                <div className="mt-1 text-xs text-zinc-500">Help us understand what you want to launch.</div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="px-6 pt-6">
              <div className="flex gap-2">
                {steps.map((_, index) => (
                  <div
                    key={index}
                    className={cn(
                      'h-1.5 flex-1 rounded-full transition-colors',
                      index <= step ? 'bg-indigo-500' : 'bg-white/10',
                    )}
                  />
                ))}
              </div>
              <div className="mt-1 text-right text-[11px] text-zinc-600">
                Step {step + 1} of {steps.length}
              </div>
            </div>

            <div className="px-6 py-8">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-6 text-center">
                <div className="text-xs font-semibold uppercase tracking-widest text-indigo-400">
                  Step {String(step + 1).padStart(2, '0')}
                </div>
                <div className="mt-3 text-lg font-semibold text-white">{steps[step].title}</div>
                <div className="mt-2 text-sm text-zinc-400">{steps[step].description}</div>
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-white/10 px-6 py-5">
              <button
                type="button"
                disabled={step === 0}
                onClick={() => setStep((current) => Math.max(0, current - 1))}
                className="rounded-full border border-white/10 bg-white/5 px-5 py-2.5 text-sm font-medium text-zinc-300 transition hover:bg-white/10 hover:text-white disabled:opacity-40"
              >
                Back
              </button>
              <button
                type="button"
                onClick={() => {
                  if (step < steps.length - 1) {
                    setStep((current) => current + 1)
                  } else {
                    onClose()
                  }
                }}
                className="rounded-full bg-indigo-500 px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400"
              >
                {step < steps.length - 1 ? 'Next' : 'Done'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}
