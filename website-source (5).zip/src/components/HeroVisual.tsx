import { motion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'
import { MessageCircle, Zap, TrendingUp, MousePointerClick } from 'lucide-react'

const chatItems = [
  { id: 1, name: 'Crypto Insider', message: 'Market news and analytics', time: '12:04', unread: 3 },
  { id: 2, name: 'Design Digest', message: 'Best projects of the week', time: '11:40', unread: 0 },
  { id: 3, name: 'Startup Club', message: 'Discussing rounds and launches', time: '10:18', unread: 12 },
]

export default function HeroVisual() {
  const [step, setStep] = useState(0)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setStep((current) => (current + 1) % 3)
    }, 2400)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [])

  return (
    <div className="relative mt-14 w-full max-w-3xl xl:mt-0 xl:max-w-none">
      <div className="absolute -inset-12 -z-10 rounded-[3rem] bg-indigo-500/10 blur-3xl" />

      <div className="grid gap-5 sm:grid-cols-[1.1fr_0.9fr]">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="glass overflow-hidden rounded-[28px] p-4 sm:p-5"
        >
          <div className="mb-4 flex items-center gap-3">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-indigo-500/20 text-indigo-300">
              <MessageCircle className="h-4 w-4" />
            </span>
            <span className="text-sm font-semibold text-white">Chat Feed</span>
          </div>

          <div className="flex flex-col gap-2">
            {chatItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-xs font-bold text-white">
                    {item.name[0]}
                  </span>
                  <div>
                    <div className="text-sm font-semibold text-white">{item.name}</div>
                    <div className="text-xs text-zinc-400">{item.message}</div>
                  </div>
                </div>
                <div className="text-right text-xs text-zinc-500">
                  {item.time}
                  {item.unread > 0 ? <div className="mt-1 text-indigo-400">{item.unread}</div> : null}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="flex flex-col gap-5">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.8, ease: 'easeOut' }}
            className="glass rounded-[24px] p-5"
          >
            <div className="mb-4 flex items-center gap-3">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-300">
                <Zap className="h-4 w-4" />
              </span>
              <span className="text-sm font-semibold text-white">Sponsored post</span>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="mb-3 flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-xs font-bold text-white">
                  S
                </span>
                <div>
                  <div className="text-sm font-semibold text-white">Spestra Ads</div>
                  <div className="text-xs text-zinc-400">Sponsored</div>
                </div>
              </div>
              <div className="text-[13px] leading-relaxed text-zinc-300">
                Launch ads in minutes. Pay per subscriber, transparent analytics, and fast start.
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs text-zinc-500">
                <MousePointerClick className="h-3.5 w-3.5 text-indigo-400" />
                Native placement in feed
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.28, duration: 0.8, ease: 'easeOut' }}
            className="glass rounded-[24px] p-5"
          >
            <div className="mb-4 flex items-center gap-3">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-amber-500/20 text-amber-300">
                <TrendingUp className="h-4 w-4" />
              </span>
              <span className="text-sm font-semibold text-white">Stories</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {['Campaigns', 'Reach', 'Subscribers'].map((label, index) => (
                <div key={label} className="rounded-2xl border border-white/10 bg-white/5 px-3 py-4 text-center">
                  <div className="text-[11px] uppercase tracking-widest text-zinc-500">{label}</div>
                  <div className="mt-2 text-base font-bold text-white">
                    {index === 0 ? '12' : index === 1 ? '846K' : '6 214'}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      <div className="mt-6 flex items-center justify-center gap-4 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-xs text-zinc-400 backdrop-blur-xl">
        <span className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-emerald-400" />
          Easy integration
        </span>
        <span className="h-3 w-px bg-white/10" />
        <span>Cross-platform targeting</span>
        <span className="hidden h-3 w-px bg-white/10 sm:block" />
        <span className="hidden sm:inline">Native formats</span>
      </div>

      <div
        className="pointer-events-none absolute -right-8 top-1/2 hidden -translate-y-1/2 rounded-full bg-indigo-500/20 px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-indigo-300 shadow-lg shadow-indigo-500/20 xl:block"
      >
        Preview
      </div>
    </div>
  )
}
