import { motion } from 'framer-motion'
import { AlertCircle, ArrowRight, CheckCircle2, MousePointerClick } from 'lucide-react'
import { problemComparison } from '@/data/site'

export default function ProblemComparison() {
  return (
    <section className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-0 h-[420px] w-[640px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            {problemComparison.title}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            {problemComparison.subtitle}
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ delay: 0.12, duration: 0.6 }}
          className="mx-auto mt-14 max-w-3xl rounded-3xl border border-rose-500/20 bg-rose-500/5 p-8 text-center backdrop-blur-xl"
        >
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/20 text-rose-400">
            <AlertCircle className="h-6 w-6" />
          </div>
          <div className="mt-5 text-4xl font-bold tracking-tight text-white sm:text-5xl">
            {problemComparison.highlight.value}
          </div>
          <div className="mt-3 text-sm leading-relaxed text-rose-200/80">
            {problemComparison.highlight.description}
          </div>
        </motion.div>

        <div className="mt-16 grid gap-6 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.16, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="text-xs font-semibold uppercase tracking-widest text-zinc-500">
              {problemComparison.traditional.title}
            </div>
            <div className="mt-6 flex flex-col gap-3">
              {problemComparison.traditional.steps.map((step, index) => (
                <div key={step} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-xs font-bold text-white">
                    {index + 1}
                  </span>
                  <span className="text-sm text-zinc-300">{step}</span>
                  {index < problemComparison.traditional.steps.length - 1 ? (
                    <ArrowRight className="ml-auto h-4 w-4 text-zinc-600" />
                  ) : (
                    <span className="ml-auto text-xs font-semibold text-rose-400">Drop off</span>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4 text-center text-sm text-zinc-300">
              Subscription conversion:{' '}
              <span className="font-semibold text-white">{problemComparison.traditional.conversion}%</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.24, duration: 0.5 }}
            className="glass relative overflow-hidden rounded-3xl p-8"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-indigo-500/20 blur-3xl" />
            <div className="relative text-xs font-semibold uppercase tracking-widest text-indigo-400">
              {problemComparison.platform.title}
            </div>
            <div className="relative mt-6 flex flex-col gap-3">
              {problemComparison.platform.steps.map((step, index) => (
                <div key={step} className="flex items-center gap-3 rounded-2xl border border-indigo-500/20 bg-indigo-500/10 px-4 py-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-500 text-xs font-bold text-white">
                    {index + 1}
                  </span>
                  <span className="text-sm font-medium text-white">{step}</span>
                  {index < problemComparison.platform.steps.length - 1 ? (
                    <ArrowRight className="ml-auto h-4 w-4 text-indigo-300" />
                  ) : (
                    <CheckCircle2 className="ml-auto h-5 w-5 text-indigo-300" />
                  )}
                </div>
              ))}
            </div>
            <div className="relative mt-6 rounded-2xl border border-indigo-500/20 bg-indigo-500/10 p-4 text-center text-sm text-indigo-200">
              Subscription conversion:{' '}
              <span className="font-semibold text-white">{problemComparison.platform.conversion}%</span>
            </div>
            <div className="relative mt-4 flex items-center justify-center gap-2 text-xs text-zinc-400">
              <MousePointerClick className="h-3.5 w-3.5 text-indigo-400" />
              Minimum steps to result
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
