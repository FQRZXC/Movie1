import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Calculator as CalcIcon } from 'lucide-react'
import { economicsDefaults } from '@/data/site'
import { formatCurrency, formatNumber } from '@/lib/format'
import { cn } from '@/lib/utils'

export default function Calculator() {
  const [budget, setBudget] = useState(economicsDefaults.budget)

  const data = useMemo(() => {
    const safeBudget = Math.max(0, budget)
    const impressions = Math.round(safeBudget / (economicsDefaults.impressions / economicsDefaults.budget))
    const clicks = Math.round((impressions * economicsDefaults.ctr) / 100)
    const platformResult = Math.round((clicks * economicsDefaults.platformConversion) / 100)
    const traditionalResult = Math.round((clicks * economicsDefaults.traditionalConversion) / 100)
    const delta = Math.max(0, platformResult - traditionalResult)

    return {
      impressions,
      ctr: economicsDefaults.ctr,
      clicks,
      platformResult,
      traditionalResult,
      delta,
    }
  }, [budget])

  const maxBarValue = Math.max(data.platformResult, data.traditionalResult, 1)

  return (
    <section id="calculator" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[620px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <CalcIcon className="h-3.5 w-3.5" />
            Interactive calculator
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            The math behind the same budget
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            Enter your budget and see how the same investment yields a fundamentally different result depending on the conversion model.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ delay: 0.16, duration: 0.5 }}
          className="mx-auto mt-14 grid max-w-5xl gap-6 lg:grid-cols-[1fr_1.3fr]"
        >
          <div className="glass rounded-3xl p-8">
            <div className="text-xs font-semibold uppercase tracking-widest text-zinc-500">Budget</div>
            <div className="mt-5 flex items-center gap-4">
              <input
                type="range"
                min={0}
                max={5000}
                step={10}
                value={budget}
                onChange={(event) => setBudget(Number(event.target.value))}
                className="h-2 flex-1 cursor-pointer appearance-none rounded-full bg-white/10 accent-indigo-500"
              />
              <div className="w-24 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-right text-sm font-semibold text-white">
                {formatCurrency(budget)}
              </div>
            </div>

            <div className="mt-8 flex flex-col gap-3">
              <ResultPill label="Impressions" value={formatNumber(data.impressions)} />
              <ResultPill label="CTR" value={`${data.ctr.toFixed(2)}%`} />
              <ResultPill label="Clicks" value={formatNumber(data.clicks)} />
              <ResultPill label="Spestra Conversion" value={`${economicsDefaults.platformConversion}%`} accent />
              <ResultPill label="Traditional Conversion" value={`${economicsDefaults.traditionalConversion}%`} />
            </div>

            <div className="mt-8 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-5 text-center">
              <div className="text-xs font-medium text-emerald-300/80">Difference</div>
              <div className="mt-2 text-2xl font-bold tracking-tight text-white">+{formatNumber(data.delta)} subscribers</div>
            </div>
          </div>

          <div className="glass rounded-3xl p-8">
            <div className="text-xs font-semibold uppercase tracking-widest text-indigo-400">Comparison of results</div>
            <div className="mt-8 flex flex-col gap-6">
              <BarResult
                label="Spestra"
                value={data.platformResult}
                maxValue={maxBarValue}
                color="bg-indigo-500"
                caption={`${formatNumber(data.platformResult)} subscribers`}
              />
              <BarResult
                label="Traditional model"
                value={data.traditionalResult}
                maxValue={maxBarValue}
                color="bg-zinc-500"
                caption={`${formatNumber(data.traditionalResult)} subscribers`}
              />
            </div>

            <div className="mt-10 grid gap-4 sm:grid-cols-3">
              <StatBox label="Spestra" value={formatCurrency(data.platformResult > 0 ? budget / data.platformResult : 0)} hint="CPS" />
              <StatBox label="Traditional" value={formatCurrency(data.traditionalResult > 0 ? budget / data.traditionalResult : 0)} hint="CPS" />
              <StatBox label="Savings" value={`+${formatNumber(data.delta)}`} hint="additional subscribers" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

function ResultPill({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={cn(
        'flex items-center justify-between rounded-2xl border px-4 py-3.5',
        accent ? 'border-indigo-500/20 bg-indigo-500/10' : 'border-white/10 bg-white/5',
      )}
    >
      <div className="text-xs text-zinc-400">{label}</div>
      <div className={cn('text-sm font-semibold', accent ? 'text-indigo-300' : 'text-white')}>{value}</div>
    </div>
  )
}

function BarResult({
  label,
  value,
  maxValue,
  color,
  caption,
}: {
  label: string
  value: number
  maxValue: number
  color: string
  caption: string
}) {
  const width = maxValue > 0 ? Math.round((value / maxValue) * 100) : 0

  return (
    <div>
      <div className="flex items-center justify-between text-xs text-zinc-400">
        <span>{label}</span>
        <span className="font-semibold text-white">{caption}</span>
      </div>
      <div className="mt-3 h-3 overflow-hidden rounded-full bg-white/10">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${width}%` }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.8, ease: 'easeOut' }}
          className={`h-full rounded-full ${color}`}
        />
      </div>
    </div>
  )
}

function StatBox({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
      <div className="text-[11px] uppercase tracking-widest text-zinc-500">{label}</div>
      <div className="mt-2 text-lg font-bold tracking-tight text-white">{value}</div>
      <div className="mt-1 text-xs text-zinc-500">{hint}</div>
    </div>
  )
}
