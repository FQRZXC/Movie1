import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { navigation, brand } from '@/data/site'
import useScrollSpy from '@/hooks/useScrollSpy'
import { cn } from '@/lib/utils'
import { useAuth } from '@/lib/auth-context'

export default function Navbar({ onOpenModal }: { onOpenModal: () => void }) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const activeId = useScrollSpy(navigation.map((item) => item.id), { offset: 160 })
  const headerRef = useRef<HTMLElement | null>(null)
  const { user, isInTelegram } = useAuth()

  useEffect(() => {
    const onScroll = () => setScrolled((window.scrollY > 24))
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      <header
        ref={headerRef}
        className={cn(
          'fixed inset-x-0 top-0 z-50 transition-all duration-300',
          scrolled ? 'glass py-3 shadow-lg shadow-black/20' : 'bg-transparent py-5',
        )}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 lg:px-8">
          <a href="#" className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500 text-sm font-bold text-white">
              S
            </span>
            <span className="text-lg font-semibold tracking-tight text-white">{brand.name}</span>
          </a>

          <nav className="hidden items-center gap-1 rounded-full border border-white/10 bg-white/5 px-1.5 py-1 backdrop-blur-xl lg:flex">
            {navigation.map((item) => (
              <a
                key={item.id}
                href={item.href}
                className={cn(
                  'rounded-full px-4 py-2 text-sm font-medium transition-all duration-200',
                  activeId === item.id
                    ? 'bg-white/10 text-white shadow-sm'
                    : 'text-zinc-400 hover:bg-white/5 hover:text-white',
                )}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            {user && isInTelegram ? (
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-white">
                    {user.first_name}
                    {user.last_name && ` ${user.last_name}`}
                  </div>
                  {user.username && (
                    <div className="text-xs text-gray-500">@{user.username}</div>
                  )}
                </div>
                <div className="w-9 h-9 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-sm font-bold text-indigo-400">
                  {user.first_name[0]}
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={onOpenModal}
                className="rounded-full bg-indigo-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400 hover:shadow-indigo-500/30"
              >
                Launch Ads
              </button>
            )}
          </div>

          <div className="flex items-center gap-3 lg:hidden">
            <button
              type="button"
              onClick={onOpenModal}
              className="rounded-full bg-indigo-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400"
            >
              Launch
            </button>
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-300 backdrop-blur-xl transition hover:bg-white/10 hover:text-white"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {mobileOpen ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm lg:hidden"
            onClick={() => setMobileOpen(false)}
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 320 }}
              className="absolute inset-y-0 right-0 w-full max-w-sm bg-[#0f0f12]/95 shadow-2xl backdrop-blur-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
                <span className="text-base font-semibold text-white">Navigation</span>
                <button
                  type="button"
                  onClick={() => setMobileOpen(false)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-300 transition hover:bg-white/10 hover:text-white"
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="flex flex-1 flex-col gap-2 p-5">
                {navigation.map((item) => (
                  <a
                    key={item.id}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      'rounded-2xl px-4 py-3.5 text-base font-medium transition',
                      activeId === item.id ? 'bg-white/10 text-white' : 'text-zinc-300 hover:bg-white/5 hover:text-white',
                    )}
                  >
                    {item.label}
                  </a>
                ))}
              </div>

              <div className="border-t border-white/10 p-5">
                {user && isInTelegram ? (
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-sm font-bold text-indigo-400">
                      {user.first_name[0]}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">
                        {user.first_name}
                        {user.last_name && ` ${user.last_name}`}
                      </div>
                      {user.username && (
                        <div className="text-xs text-gray-500">@{user.username}</div>
                      )}
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setMobileOpen(false)
                      onOpenModal()
                    }}
                    className="w-full rounded-2xl bg-indigo-500 px-5 py-3.5 text-base font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:bg-indigo-400"
                  >
                    Launch Ads
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  )
}
