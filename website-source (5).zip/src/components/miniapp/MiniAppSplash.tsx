import { useEffect, useRef, useState } from 'react'

export default function MiniAppSplash({ onEnter }: { onEnter: () => void }) {
  const [progress, setProgress] = useState(0)
  const onEnterRef = useRef(onEnter)
  onEnterRef.current = onEnter

  useEffect(() => {
    let cancelled = false
    const timer = setInterval(() => {
      if (cancelled) return
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(timer)
          setTimeout(() => {
            if (!cancelled) onEnterRef.current()
          }, 300)
          return 100
        }
        return p + 4
      })
    }, 30)
    return () => {
      cancelled = true
      clearInterval(timer)
    }
  }, [])

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0b0b0e]">
      <div className="flex flex-col items-center gap-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-2xl font-bold text-white shadow-lg shadow-indigo-500/30">
          iM
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold text-white">imeads</div>
          <div className="text-sm text-zinc-500">Advertising Platform</div>
        </div>
        <div className="w-48">
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-2 text-center text-xs text-zinc-600">{progress}%</div>
        </div>
      </div>
    </div>
  )
}
