import { Settings, Plus, Pause, Play, ChevronRight, Users, Bell, CreditCard, Shield, LogOut, Eye, EyeOff } from 'lucide-react'

interface Campaign {
  id: number
  name: string
  status: string
  budget: number
  spent: number
  impressions: number
  clicks: number
  ctr: number
}

interface Props {
  balance: number
  showBalance: boolean
  onToggleBalance: () => void
  campaigns: Campaign[]
  onNewCampaign: () => void
  onSettings: () => void
  onPauseToggle: (id: number) => void
  activeTab: 'overview' | 'campaigns' | 'settings'
  onTabChange: (tab: 'overview' | 'campaigns' | 'settings') => void
}

const statusLabel: Record<string, string> = {
  active: 'Активна',
  paused: 'На паузе',
  completed: 'Завершена',
}

const statusColor: Record<string, string> = {
  active: 'bg-emerald-500 text-white',
  paused: 'bg-yellow-500 text-white',
  completed: 'bg-zinc-500 text-white',
}

export default function MiniAppDashboard({
  balance,
  showBalance,
  onToggleBalance,
  campaigns,
  onNewCampaign,
  onSettings,
  onPauseToggle,
  activeTab,
  onTabChange,
}: Props) {
  const stats = [
    { label: 'Охват', value: '1.2M', icon: '👁', color: 'from-indigo-500/20 to-indigo-500/5' },
    { label: 'Клики', value: '18.4K', icon: '🖱', color: 'from-violet-500/20 to-violet-500/5' },
    { label: 'CTR', value: '1.5%', icon: '📈', color: 'from-emerald-500/20 to-emerald-500/5' },
    { label: 'Конверсии', value: '342', icon: '🎯', color: 'from-amber-500/20 to-amber-500/5' },
  ]

  return (
    <div className="fixed inset-0 flex flex-col bg-[#0a0a0f] text-white">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-sm font-bold shadow-lg shadow-indigo-500/20">iM</div>
          <div>
            <div className="text-sm font-semibold">imeads</div>
            <div className="text-xs text-zinc-500">Рекламный кабинет</div>
          </div>
        </div>
        <button
          onClick={onSettings}
          className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
        >
          <Settings className="h-4 w-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24">
        {activeTab === 'overview' && (
          <>
            {/* Balance card */}
            <div className="rounded-2xl border border-indigo-500/20 bg-gradient-to-br from-indigo-500/10 to-violet-500/5 p-5">
              <div className="flex items-center justify-between">
                <div className="text-xs text-zinc-400">Баланс</div>
                <button onClick={onToggleBalance} className="text-zinc-500 transition hover:text-white">
                  {showBalance ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              <div className="mt-1 text-3xl font-bold tracking-tight">
                {showBalance ? `$${balance.toLocaleString('ru-RU')}` : '••••'}
              </div>
              <div className="mt-1 text-xs text-indigo-400">+15% бонус за первое пополнение</div>
              <div className="mt-4 flex gap-2">
                <button className="flex-1 rounded-xl bg-indigo-500 py-2.5 text-xs font-semibold transition hover:bg-indigo-400 shadow-lg shadow-indigo-500/20">
                  Пополнить
                </button>
                <button className="flex-1 rounded-xl border border-white/10 bg-white/5 py-2.5 text-xs font-medium text-zinc-300 transition hover:bg-white/10">
                  Вывести
                </button>
              </div>
            </div>

            {/* Stats grid 2x2 */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              {stats.map((s) => (
                <div key={s.label} className={`rounded-2xl border border-white/10 bg-gradient-to-br ${s.color} p-4`}>
                  <div className="text-xs text-zinc-500">{s.label}</div>
                  <div className="mt-1 text-xl font-bold">{s.value}</div>
                </div>
              ))}
            </div>

            {/* Referral banner */}
            <div className="mt-4 rounded-2xl border border-emerald-500/20 bg-gradient-to-r from-emerald-500/10 to-teal-500/5 p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-500/20 text-2xl">🎁</div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-emerald-300">Реферальная программа</div>
                  <div className="mt-0.5 text-xs text-zinc-400">Приглашайте друзей и получайте 10% от их пополнений</div>
                </div>
                <ChevronRight className="h-4 w-4 text-emerald-500/50" />
              </div>
            </div>

            {/* Quick actions */}
            <div className="mt-4">
              <div className="mb-3 text-sm font-semibold text-zinc-300">Быстрые действия</div>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={onNewCampaign}
                  className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:bg-white/[0.06]"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
                    <Plus className="h-5 w-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium">Новая кампания</div>
                    <div className="text-xs text-zinc-500">Создать и запустить</div>
                  </div>
                </button>
                <button
                  onClick={onTabChange.bind(null, 'campaigns')}
                  className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:bg-white/[0.06]"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/20 text-violet-400">
                    <Users className="h-5 w-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium">Все кампании</div>
                    <div className="text-xs text-zinc-500">{campaigns.length} шт.</div>
                  </div>
                </button>
              </div>
            </div>
          </>
        )}

        {activeTab === 'campaigns' && (
          <div>
            <div className="mb-4 flex items-center justify-between">
              <div className="text-sm font-semibold text-zinc-300">Все кампании</div>
              <button
                onClick={onNewCampaign}
                className="flex items-center gap-1 rounded-xl bg-indigo-500 px-3 py-1.5 text-xs font-semibold transition hover:bg-indigo-400"
              >
                <Plus className="h-3.5 w-3.5" /> Создать
              </button>
            </div>
            {campaigns.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/10 py-10 text-center text-sm text-zinc-600">
                Нет кампаний. Нажмите «Создать» чтобы начать.
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {campaigns.map((c) => (
                  <div key={c.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-sm font-medium text-white">{c.name}</div>
                        <div className="mt-1.5 flex items-center gap-2">
                          <span className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${statusColor[c.status]}`}>
                            {statusLabel[c.status]}
                          </span>
                          <span className="text-[10px] text-zinc-600">Бюджет ${c.budget.toLocaleString()}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => onPauseToggle(c.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                      >
                        {c.status === 'active' ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    <div className="mt-3 grid grid-cols-4 gap-2 text-center">
                      <div>
                        <div className="text-[10px] text-zinc-600">Потрачено</div>
                        <div className="text-xs font-semibold">${c.spent.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-zinc-600">Показы</div>
                        <div className="text-xs font-semibold">{c.impressions.toLocaleString('ru-RU')}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-zinc-600">Клики</div>
                        <div className="text-xs font-semibold">{c.clicks.toLocaleString('ru-RU')}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-zinc-600">CTR</div>
                        <div className="text-xs font-semibold">{c.ctr}%</div>
                      </div>
                    </div>
                    <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500"
                        style={{ width: `${Math.min((c.spent / c.budget) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div>
            {/* Profile */}
            <div className="mb-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-sm font-bold">iM</div>
              <div>
                <div className="text-sm font-medium text-white">imeads Account</div>
                <div className="text-xs text-zinc-500">user@imeads.app</div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              {[
                { icon: Bell, label: 'Уведомления', desc: 'Push-уведомления, email', color: 'text-amber-400' },
                { icon: Shield, label: 'Безопасность', desc: '2FA, сессии, пароль', color: 'text-emerald-400' },
                { icon: CreditCard, label: 'Способы оплаты', desc: 'Карты, реквизиты', color: 'text-indigo-400' },
                { icon: Users, label: 'Реферальная программа', desc: 'Приглашайте друзей', color: 'text-violet-400' },
              ].map(({ icon: Icon, label, desc, color }) => (
                <button
                  key={label}
                  className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:bg-white/[0.06]"
                >
                  <div className="flex items-center gap-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 ${color}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="text-left">
                      <div className="text-sm font-medium text-white">{label}</div>
                      <div className="text-xs text-zinc-500">{desc}</div>
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-zinc-600" />
                </button>
              ))}
            </div>

            <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/5 py-3.5 text-sm font-medium text-red-400 transition hover:bg-red-500/10">
              <LogOut className="h-4 w-4" />
              Выйти из аккаунта
            </button>
          </div>
        )}
      </div>

      {/* Bottom navigation */}
      <div className="fixed bottom-0 left-0 right-0 border-t border-white/10 bg-[#0a0a0f]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-lg items-center justify-around py-2">
          {[
            { key: 'overview' as const, label: 'Обзор', icon: '📊' },
            { key: 'campaigns' as const, label: 'Кампании', icon: '📢' },
            { key: 'settings' as const, label: 'Настройки', icon: '⚙️' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => onTabChange(tab.key)}
              className={`flex flex-col items-center gap-1 px-4 py-1.5 transition ${activeTab === tab.key ? 'text-indigo-400' : 'text-zinc-600'}`}
            >
              <span className="text-lg">{tab.icon}</span>
              <span className="text-[10px] font-medium">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
