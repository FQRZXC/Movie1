import { ArrowLeft, ChevronRight } from 'lucide-react'
import type { CampaignDraft } from './MiniApp'

interface Props {
  draft: CampaignDraft
  onUpdate: (patch: Partial<CampaignDraft>) => void
  onBack: () => void
  onNext: () => void
}

const channels = ['Telegram', 'VK', 'MAX', 'ТикТок']
const geos = ['Все страны', 'Россия', 'СНГ', 'Европа', 'Азия', 'Африка']
const audiences = ['Все', 'Мужчины 18-34', 'Женщины 18-34', 'Мужчины 35-55', 'Женщины 35-55', 'IT-специалисты', 'Бизнес']

export default function MiniAppNewCampaign({ draft, onUpdate, onBack, onNext }: Props) {
  const valid = draft.name.trim().length > 0

  return (
    <div className="fixed inset-0 flex flex-col bg-[#0b0b0e] text-white">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-4 pb-3">
        <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="text-sm font-semibold">Новая кампания</div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24">
        {/* Step indicator */}
        <div className="mb-5 flex items-center gap-2">
          {[1, 2, 3].map((s) => (
            <div key={s} className={`h-1 flex-1 rounded-full ${s <= 2 ? 'bg-indigo-500' : 'bg-white/10'}`} />
          ))}
        </div>
        <div className="mb-4 text-xs text-zinc-500">Шаг 1 из 3 — Основные настройки</div>

        {/* Campaign name */}
        <label className="mb-1 block text-xs text-zinc-500">Название кампании</label>
        <input
          value={draft.name}
          onChange={(e) => onUpdate({ name: e.target.value })}
          placeholder="Например: Запуск в Telegram"
          className="mb-5 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/30"
        />

        {/* Channel */}
        <label className="mb-1 block text-xs text-zinc-500">Канал</label>
        <div className="mb-5 flex flex-wrap gap-2">
          {channels.map((ch) => (
            <button
              key={ch}
              onClick={() => onUpdate({ channel: ch })}
              className={`rounded-xl px-4 py-2.5 text-xs font-medium transition ${
                draft.channel === ch
                  ? 'bg-indigo-500 text-white'
                  : 'border border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10'
              }`}
            >
              {ch}
            </button>
          ))}
        </div>

        {/* Geo */}
        <label className="mb-1 block text-xs text-zinc-500">Гео-таргетинг</label>
        <div className="mb-5 flex flex-wrap gap-2">
          {geos.map((g) => (
            <button
              key={g}
              onClick={() => onUpdate({ geo: g })}
              className={`rounded-xl px-4 py-2.5 text-xs font-medium transition ${
                draft.geo === g
                  ? 'bg-indigo-500 text-white'
                  : 'border border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10'
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Audience */}
        <label className="mb-1 block text-xs text-zinc-500">Аудитория</label>
        <div className="mb-5 flex flex-wrap gap-2">
          {audiences.map((a) => (
            <button
              key={a}
              onClick={() => onUpdate({ audience: a })}
              className={`rounded-xl px-4 py-2.5 text-xs font-medium transition ${
                draft.audience === a
                  ? 'bg-indigo-500 text-white'
                  : 'border border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10'
              }`}
            >
              {a}
            </button>
          ))}
        </div>

        {/* Budget */}
        <label className="mb-1 block text-xs text-zinc-500">Бюджет: ${draft.budget.toLocaleString()}</label>
        <input
          type="range"
          min={100}
          max={50000}
          step={100}
          value={draft.budget}
          onChange={(e) => onUpdate({ budget: Number(e.target.value) })}
          className="mb-2 w-full accent-indigo-500"
        />
        <div className="mb-5 flex justify-between text-[10px] text-zinc-600">
          <span>$100</span>
          <span>$50 000</span>
        </div>

        {/* CPM */}
        <label className="mb-1 block text-xs text-zinc-500">Макс. CPM: ${draft.cpm.toFixed(2)}</label>
        <input
          type="range"
          min={0.1}
          max={5}
          step={0.05}
          value={draft.cpm}
          onChange={(e) => onUpdate({ cpm: Number(e.target.value) })}
          className="mb-2 w-full accent-indigo-500"
        />
        <div className="mb-5 flex justify-between text-[10px] text-zinc-600">
          <span>$0.10</span>
          <span>$5.00</span>
        </div>

        {/* Preview */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <div className="text-xs text-zinc-500">Предварительный расчёт</div>
          <div className="mt-2 grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-[10px] text-zinc-600">Охват</div>
              <div className="text-sm font-bold text-indigo-400">
                {formatNum(Math.round((draft.budget / draft.cpm) * 1000))}
              </div>
            </div>
            <div>
              <div className="text-[10px] text-zinc-600">Показы</div>
              <div className="text-sm font-bold text-indigo-400">
                {formatNum(Math.round((draft.budget / draft.cpm) * 1000))}
              </div>
            </div>
            <div>
              <div className="text-[10px] text-zinc-600">Клики (≈2%)</div>
              <div className="text-sm font-bold text-indigo-400">
                {formatNum(Math.round((draft.budget / draft.cpm) * 20))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Next */}
      <div className="fixed bottom-6 left-5 right-5">
        <button
          onClick={onNext}
          disabled={!valid}
          className={`flex w-full items-center justify-center gap-2 rounded-2xl py-4 text-sm font-semibold transition ${
            valid
              ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 hover:bg-indigo-400 active:scale-[0.98]'
              : 'bg-white/5 text-zinc-600'
          }`}
        >
          Далее: Креатив <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}

function formatNum(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return String(n)
}
