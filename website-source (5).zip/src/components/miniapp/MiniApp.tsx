import { useState } from 'react'
import MiniAppSplash from './MiniAppSplash'
import MiniAppDashboard from './MiniAppDashboard'
import MiniAppNewCampaign from './MiniAppNewCampaign'
import MiniAppCreative from './MiniAppCreative'
import MiniAppPayment from './MiniAppPayment'

export type MiniAppScreen =
  | 'splash'
  | 'dashboard'
  | 'new-campaign'
  | 'creative'
  | 'payment'

export type TabKey = 'overview' | 'campaigns' | 'settings'

export interface CampaignDraft {
  name: string
  channel: string
  geo: string
  budget: number
  cpm: number
  audience: string
  creativeName: string
}

const defaultDraft: CampaignDraft = {
  name: '',
  channel: 'Telegram',
  geo: 'All countries',
  budget: 1000,
  cpm: 0.5,
  audience: 'All',
  creativeName: '',
}

export default function MiniApp() {
  const [screen, setScreen] = useState<MiniAppScreen>('splash')
  const [activeTab, setActiveTab] = useState<TabKey>('overview')
  const [draft, setDraft] = useState<CampaignDraft>(defaultDraft)
  const [campaigns, setCampaigns] = useState([
    { id: 1, name: 'Telegram Launch', status: 'active', budget: 1500, spent: 320, impressions: 640000, clicks: 12800, ctr: 2.0 },
    { id: 2, name: 'VK Max Coverage', status: 'paused', budget: 800, spent: 150, impressions: 300000, clicks: 4500, ctr: 1.5 },
  ])
  const [balance, setBalance] = useState(5000)
  const [showBalance, setShowBalance] = useState(true)

  const updateDraft = (patch: Partial<CampaignDraft>) => setDraft((d) => ({ ...d, ...patch }))

  const goToPayment = () => {
    setScreen('payment')
  }

  const handlePaymentSuccess = () => {
    // Credit the balance
    setBalance((b) => b + draft.budget)
    // Add the campaign
    setCampaigns((prev) => [
      {
        id: Date.now(),
        name: draft.name,
        status: 'active',
        budget: draft.budget,
        spent: 0,
        impressions: 0,
        clicks: 0,
        ctr: 0,
      },
      ...prev,
    ])
    setDraft(defaultDraft)
    setScreen('dashboard')
    setActiveTab('campaigns')
  }

  if (screen === 'splash') {
    return <MiniAppSplash onEnter={() => setScreen('dashboard')} />
  }

  if (screen === 'dashboard') {
    return (
      <MiniAppDashboard
        balance={balance}
        showBalance={showBalance}
        onToggleBalance={() => setShowBalance((b) => !b)}
        campaigns={campaigns}
        onNewCampaign={() => setScreen('new-campaign')}
        onSettings={() => { setScreen('dashboard'); setActiveTab('settings') }}
        onPauseToggle={(id) =>
          setCampaigns((prev) =>
            prev.map((c) =>
              c.id === id ? { ...c, status: c.status === 'active' ? 'paused' : 'active' } : c,
            ),
          )
        }
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
    )
  }

  if (screen === 'new-campaign') {
    return (
      <MiniAppNewCampaign
        draft={draft}
        onUpdate={updateDraft}
        onBack={() => setScreen('dashboard')}
        onNext={() => setScreen('creative')}
      />
    )
  }

  if (screen === 'creative') {
    return (
      <MiniAppCreative
        draft={draft}
        onUpdate={updateDraft}
        onBack={() => setScreen('new-campaign')}
        onLaunch={goToPayment}
      />
    )
  }

  if (screen === 'payment') {
    return (
      <MiniAppPayment
        amount={draft.budget}
        onBack={() => setScreen('creative')}
        onSuccess={handlePaymentSuccess}
      />
    )
  }

  return null
}
