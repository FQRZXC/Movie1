import { ArrowLeft, Upload, Rocket } from 'lucide-react'
import { useState } from 'react'
import type { CampaignDraft } from './MiniApp'

interface Props {
  draft: CampaignDraft
  onUpdate: (patch: Partial<CampaignDraft>) => void
  onBack: () => void
  onLaunch: () => void
}

export default function MiniAppCreative({ draft, onUpdate, onBack, onLaunch }: Props) {
  const [uploaded, setUploaded] = useState(false)
  const valid = draft.name.trim().length > 0

  return (
    <div className="fixed inset-0 flex flex-col bg-[#0b0b0e] text-white">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-4 pb-3">
        <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="text-sm font-semibold">Креатив</div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24">
        {/* Step indicator */}
        <div className="mb-5 flex items-center gap-2">
          {[1, 2, 3].map((s) => (
            <div key={s} className={`h-1 flex-1 rounded-full ${s <= 3 ? 'bg-indigo-500' : 'bg-white/10'}`} />
          ))}
        </div>
        <div className="mb-4 text-xs text-zinc-500">Шаг 2 из 3 — Загрузка креатива</div>

        {/* Upload area */}
        <div
          onClick={() => setUploaded(true)}
          className={`flex flex-col items-center justify-center rounded-2xl border-2 border-dashed p-10 transition ${
            uploaded
              ? 'border-emerald-500/40 bg-emerald-500/5'
              : 'border-white/10 bg-white/[0.02] hover:border-indigo-500/40 hover:bg-indigo-500/5'
          }`}
        >
          {uploaded ? (
            <>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400">
                <Upload className="h-5 w-5" />
              </div>
              <div className="mt-3 text-sm font-medium text-emerald-400">Креатив загружен</div>
              <div className="mt-1 text-xs text-zinc-500">Нажмите чтобы заменить</div>
            </>
          ) : (
            <>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 text-zinc-500">
                <Upload className="h-5 w-5" />
              </div>
              <div className="mt-3 text-sm font-medium text-zinc-300">Загрузите креатив</div>
              <div className="mt-1 text-xs text-zinc-600">Изображение или видео до 10 МБ</div>
            </>
          )}
        </div>

        {/* Creative name */}
        <label className="mb-1 mt-5 block text-xs text-zinc-500">Название креатива</label>
        <input
          value={draft.creativeName}
          onChange={(e) => onUpdate({ creativeName: e.target.value })}
          placeholder="Например: Баннер 1080x1080"
          className="mb-5 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/30"
        />

        {/* Preview card */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <div className="text-xs text-zinc-500">Превью объявления</div>
          <div className="mt-3 flex gap-3">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400">
              <Upload className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium text-white">{draft.name || 'Название кампании'}</div>
              <div className="mt-0.5 text-xs text-zinc-500">{draft.channel} · {draft.geo}</div>
              <div className="mt-1 text-xs text-zinc-600">Бюджет: ${draft.budget.toLocaleString()} · CPM: ${draft.cpm.toFixed(2)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Launch */}
      <div className="fixed bottom-6 left-5 right-5">
        <button
          onClick={onLaunch}
          disabled={!valid}
          className={`flex w-full items-center justify-center gap-2 rounded-2xl py-4 text-sm font-semibold transition ${
            valid
              ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 hover:bg-indigo-400 active:scale-[0.98]'
              : 'bg-white/5 text-zinc-600'
          }`}
        >
          <Rocket className="h-4 w-4" /> Запустить кампанию
        </button>
      </div>
    </div>
  )
}
