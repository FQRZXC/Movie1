import { ArrowLeft, Clock, Copy, CheckCircle2, AlertTriangle } from 'lucide-react'
import { useState, useEffect, useCallback } from 'react'
import { networks, type NetworkKey } from '@/config'

interface Props {
  amount: number
  onBack: () => void
  onSuccess: () => void
}

const TIMER_SECONDS = 30 * 60 // 30 minutes

function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

export default function MiniAppPayment({ amount, onBack, onSuccess }: Props) {
  const [selectedNetwork, setSelectedNetwork] = useState<NetworkKey>('trc20')
  const [copied, setCopied] = useState(false)
  const [timer, setTimer] = useState(TIMER_SECONDS)
  const [expired, setExpired] = useState(false)
  const [status, setStatus] = useState<'waiting' | 'confirming' | 'success'>('waiting')

  const activeNetwork = networks.find((n) => n.key === selectedNetwork)!

  useEffect(() => {
    if (expired || status !== 'waiting') return
    const interval = setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          clearInterval(interval)
          setExpired(true)
          return 0
        }
        return t - 1
      })
    }, 1000)
    return () => clearInterval(interval)
  }, [expired, status])

  // Simulate payment detection after 15 seconds
  useEffect(() => {
    if (status !== 'waiting' || expired) return
    const timeout = setTimeout(() => {
      setStatus('confirming')
      // Simulate confirmation after 5 more seconds
      setTimeout(() => {
        setStatus('success')
      }, 5000)
    }, 15000)
    return () => clearTimeout(timeout)
  }, [status, expired])

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(activeNetwork.wallet)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [activeNetwork.wallet])

  if (expired) {
    return (
      <div className="fixed inset-0 flex flex-col bg-[#0b0b0e] text-white">
        <div className="flex items-center gap-3 px-4 pt-4 pb-3">
          <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white">
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="text-sm font-semibold">Payment expired</div>
        </div>
        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-red-500/15 text-red-400">
            <AlertTriangle className="h-8 w-8" />
          </div>
          <div className="mt-5 text-lg font-semibold text-white">Payment expired</div>
          <div className="mt-2 text-sm text-zinc-400">
            The payment window has closed. Create a new campaign to try again.
          </div>
          <button
            onClick={onSuccess}
            className="mt-6 rounded-2xl bg-indigo-500 px-8 py-3 text-sm font-semibold text-white transition hover:bg-indigo-400"
          >
            Create New Campaign
          </button>
        </div>
      </div>
    )
  }

  if (status === 'success') {
    return (
      <div className="fixed inset-0 flex flex-col bg-[#0b0b0e] text-white">
        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-400">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <div className="mt-5 text-lg font-semibold text-white">Payment confirmed!</div>
          <div className="mt-2 text-sm text-zinc-400">
            ${amount.toLocaleString()} has been credited to your balance via {activeNetwork.name}.
          </div>
          <div className="mt-2 text-xs text-zinc-600">Confirmation in {activeNetwork.chain} network</div>
          <button
            onClick={onSuccess}
            className="mt-6 rounded-2xl bg-indigo-500 px-8 py-3 text-sm font-semibold text-white transition hover:bg-indigo-400"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 flex flex-col bg-[#0b0b0e] text-white">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-4 pb-3">
        <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="text-sm font-semibold">Payment</div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24">
        {/* Timer */}
        <div className="mb-5 flex items-center justify-center gap-2 rounded-2xl border border-amber-500/20 bg-amber-500/5 px-4 py-3">
          <Clock className="h-4 w-4 text-amber-400" />
          <span className="text-sm font-mono font-semibold text-amber-400">{formatTime(timer)}</span>
          <span className="text-xs text-zinc-500">remaining</span>
        </div>

        {/* Amount */}
        <div className="mb-5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 p-5 text-center">
          <div className="text-xs text-zinc-500">Amount due</div>
          <div className="mt-1 text-3xl font-bold text-white">${amount.toLocaleString()}</div>
          <div className="mt-1 text-xs text-indigo-400">USDT</div>
        </div>

        {/* Network selector */}
        <div className="mb-5">
          <div className="mb-2 text-xs text-zinc-500">Network</div>
          <div className="flex flex-col gap-2">
            {networks.map((n) => (
              <button
                key={n.key}
                onClick={() => setSelectedNetwork(n.key as NetworkKey)}
                className={`flex items-center gap-3 rounded-2xl border p-4 transition ${
                  selectedNetwork === n.key
                    ? `${n.colorBorder} ${n.colorBg} border-2`
                    : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'
                }`}
              >
                <span className="text-xl">{n.icon}</span>
                <div className="text-left">
                  <div className={`text-sm font-medium ${selectedNetwork === n.key ? n.colorText : 'text-white'}`}>{n.name}</div>
                  <div className="text-xs text-zinc-500">{n.chain}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Wallet address */}
        {status === 'confirming' ? (
          <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5 text-center">
            <div className="flex justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-amber-400 border-t-transparent" />
            </div>
            <div className="mt-3 text-sm font-medium text-amber-400">
              Confirming transaction in {activeNetwork.chain} network
            </div>
            <div className="mt-1 text-xs text-zinc-500">Please wait...</div>
          </div>
        ) : (
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <div className="mb-2 text-xs text-zinc-500">Payment address ({activeNetwork.name})</div>
            <div className="flex items-center gap-2">
              <div className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-3 font-mono text-xs text-zinc-300 break-all">
                {activeNetwork.wallet}
              </div>
              <button
                onClick={handleCopy}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
              >
                {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>

            <div className="mt-4 rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-center text-xs text-amber-400">
              ⚠️ Send USDT only through {activeNetwork.chain} ({activeNetwork.name}) network. Sending via another network may result in permanent loss of funds.
            </div>
          </div>
        )}

        {/* Status indicator */}
        <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-center text-xs text-zinc-500">
          Waiting for transaction confirmation in {activeNetwork.chain} network
        </div>
      </div>
    </div>
  )
}
