import { ArrowLeft, Bell, Shield, CreditCard, ChevronRight, LogOut } from 'lucide-react'

interface Props {
  onBack: () => void
}

export default function MiniAppSettings({ onBack }: Props) {
  return (
    <div className="fixed inset-0 flex flex-col bg-[#0b0b0e] text-white">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-4 pb-3">
        <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-400 transition hover:bg-white/10 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="text-sm font-semibold">Настройки</div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24">
        {/* Profile */}
        <div className="mb-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-500 text-sm font-bold">iM</div>
          <div>
            <div className="text-sm font-medium text-white">imeads Account</div>
            <div className="text-xs text-zinc-500">user@imeads.app</div>
          </div>
        </div>

        {/* Menu items */}
        <div className="flex flex-col gap-2">
          {[
            { icon: Bell, label: 'Уведомления', desc: 'Push-уведомления, email' },
            { icon: Shield, label: 'Безопасность', desc: '2FA, сессии, пароль' },
            { icon: CreditCard, label: 'Способы оплаты', desc: 'Карты, реквизиты' },
          ].map(({ icon: Icon, label, desc }) => (
            <button
              key={label}
              className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:bg-white/[0.06]"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-zinc-400">
                  <Icon className="h-4 w-4" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-medium text-white">{label}</div>
                  <div className="text-xs text-zinc-500">{desc}</div>
                </div>
              </div>
              <ChevronRight className="h-4 w-4 text-zinc-600" />
            </button>
          ))}
        </div>

        {/* Logout */}
        <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/5 py-3.5 text-sm font-medium text-red-400 transition hover:bg-red-500/10">
          <LogOut className="h-4 w-4" />
          Выйти из аккаунта
        </button>
      </div>
    </div>
  )
}
