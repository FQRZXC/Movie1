import { motion } from 'framer-motion'
import { BarChart3, Smartphone, Users } from 'lucide-react'
import { audienceMetrics, deviceDistribution } from '@/data/site'
import useCountUp from '@/hooks/useCountUp'
import { formatNumber } from '@/lib/format'

export default function Audience() {
  return (
    <section id="audience" className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/2 top-1/2 h-[520px] w-[640px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300"
          >
            <Users className="h-3.5 w-3.5" />
            Platform audience
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.08, duration: 0.5 }}
            className="mt-6 text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl"
          >
            The audience behind the platform
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="mt-5 text-base leading-relaxed text-zinc-400 lg:text-lg"
          >
            A large, tech-active user base already accustomed to fast digital products and online payments.
          </motion.p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-[1fr_1fr]">
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.16, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="grid grid-cols-2 gap-4">
              {audienceMetrics.map((item, index) => (
                <AudienceMetric key={item.label} item={item} index={index} />
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.24, duration: 0.5 }}
            className="glass rounded-3xl p-8"
          >
            <div className="flex items-center gap-3">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-300">
                <Smartphone className="h-4 w-4" />
              </span>
              <span className="text-sm font-semibold text-white">Platform distribution</span>
            </div>

            <div className="mt-6 flex flex-col gap-3">
              {deviceDistribution.map((item) => (
                <div key={item.platform} className="flex items-center gap-4">
                  <div className="w-20 text-xs font-medium text-zinc-300">{item.platform}</div>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${item.share}%` }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.4, duration: 0.8, ease: 'easeOut' }}
                      className="h-full rounded-full bg-indigo-500"
                    />
                  </div>
                  <div className="w-10 text-right text-xs font-semibold text-white">{item.share}%</div>
                </div>
              ))}
            </div>

            <div className="mt-8 rounded-2xl border border-white/10 bg-white/5 p-4 text-xs leading-relaxed text-zinc-400">
              We work with a real messenger audience: real users on real devices.
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function AudienceMetric({ item, index }: { item: (typeof audienceMetrics)[number]; index: number }) {
  const numeric = Number.parseFloat(item.value.replace(/[^0-9.]/g, '')) || 0
  const count = useCountUp(numeric)
  const suffix = item.value.replace(/[0-9.]/g, '')

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ delay: 0.18 + index * 0.04, duration: 0.45 }}
      className="rounded-2xl border border-white/10 bg-white/5 p-5"
    >
      <div className="flex items-center gap-3">
        <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-300">
          <BarChart3 className="h-4 w-4" />
        </span>
        <span className="text-xs font-medium text-zinc-400">{item.label}</span>
      </div>
      <div className="mt-4 text-2xl font-bold tracking-tight text-white">
        {formatNumber(count)}
        {suffix}
      </div>
    </motion.div>
  )
}
