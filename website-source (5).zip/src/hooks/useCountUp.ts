import { useEffect, useRef, useState } from 'react'

export default function useCountUp(target: number, { duration = 1800, active = true }: { duration?: number; active?: boolean } = {}) {
  const [current, setCurrent] = useState(0)
  const startedAt = useRef<number | null>(null)
  const frameRef = useRef<number | null>(null)

  useEffect(() => {
    if (!active) return
    startedAt.current = null

    const tick = (now: number) => {
      if (startedAt.current === null) startedAt.current = now
      const elapsed = now - startedAt.current
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCurrent(Math.floor(eased * target))

      if (progress < 1) {
        frameRef.current = requestAnimationFrame(tick)
      } else {
        setCurrent(target)
      }
    }

    frameRef.current = requestAnimationFrame(tick)
    return () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current)
    }
  }, [active, duration, target])

  return current
}
