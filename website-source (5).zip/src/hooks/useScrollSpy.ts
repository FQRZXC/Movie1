import { useEffect, useState } from 'react'

export default function useScrollSpy(ids: string[], { offset = 140 }: { offset?: number } = {}) {
  const [activeId, setActiveId] = useState(ids[0])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries.find((item) => item.isIntersecting)
        if (entry) {
          const target = entry.target as HTMLElement
          if (target.id) {
            setActiveId(target.id)
          }
        }
      },
      { rootMargin: `-${offset}px 0px -60% 0px`, threshold: 0.15 },
    )

    ids.forEach((id) => {
      const node = document.getElementById(id)
      if (node) observer.observe(node)
    })

    return () => observer.disconnect()
  }, [ids, offset])

  return activeId
}
