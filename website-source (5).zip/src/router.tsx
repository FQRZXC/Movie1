import { createBrowserRouter } from 'react-router-dom'
import Home from './pages/Home'
import MiniAppPage from './pages/MiniAppPage'
import NotFound from './pages/NotFound'

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
  },
  {
    path: '/app',
    element: <MiniAppPage />,
  },
  {
    path: '*',
    element: <NotFound />,
  },
])
